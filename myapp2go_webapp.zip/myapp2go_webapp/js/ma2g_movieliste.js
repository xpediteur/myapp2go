

function getmovieListe(id, typ , color , bgcolor) {

	if (global_appmodus === true) {

	var countobj = retrieveJSONData('modulesbuffer');
	
	var str_header = getJSONObject(countobj, 'movie') ; // headername holen aus JSON modulname

	$('#MovieListPageHeader').text(str_header); // Header name setzten

	}

	var moviename_merker = '';

	$.mobile.loading('show');

	$.getJSON(serviceURL + 'getmovieliste.php?id=' + id, function(data) {

		
		$('#movieItemListLi li').remove();

		
		movies = data.items;

		//console.log(data);
		
		
		$.each(movies, function(index, movieItem) {


			var htmldetail = movieItem.ItemDetails.replace(/(\r\n|\n|\r)/gm, "<br />");

			htmldetail = htmlDecode(htmldetail);
			

			var split = movieItem.picname.split('.');

			var file          = split[0];
			var extension     = split[1];

			moviename_merker = movieItem.picname;

			if (extension == 'mp4') {

				movieItem.picname = 'mp4_logo.png';

			}

		
			$('#movieItemListLi').append('<li data-icon="arrow-d" style="background:' + bgcolor + ';"><a href="#" class="MovieListInternal"  data-identifierID="' + movieItem.ItemId + '"  data-identifier="' + movieItem.ItemHeading + '" data-identifierpic="' + moviename_merker + '"  data-identifierdetail="' + movieItem.ItemDetails + '" >' +

				'<img src="customerpics/' + movieItem.picname + '" style="width:75px;height:75px;margin-left:3px;margin-top:3px;margin-bottom:5px;"/>' +

				'<h5 style="color:' + color + ' ;">' + movieItem.ItemHeading + '</h5>' +

				'<p style="color:' + color + ' ;">' +  htmldetail + '</p>' +

				'<span class="ui-li-count" style="color:' + color + ' ;">' + extension + '</span>' +

				'</a></li>');


				//$('#debugInfo').append('debug -> user.Nr # ' + userItem.Nr + ' #<br> ');
				// $('#debugInfo').append('debug -> user.couponItem # ' + couponItem.couponItem + ' #<br> ');


			});



$('#movieItemListLi').listview('refresh');



$.mobile.loading('hide');



});
}



// Anzahl objekte in json-file
function countProperties(obj) {
	var prop;
	var propCount = 0;

	for (prop in obj) {
		propCount++;
	}
	return propCount;
}
