

//dynamic

var baseURL     = "http://www.m.myapp2go.de/";


var ListItemColor   = "#000000";
var ListItembgColor = "#F3E1B9";


 window.location.href = baseURL + 'ma2gnotactiv.html';

// var custPicture       = "heigl_top.png";
