// var serviceURL = "http://system3-consulting.de/myapp2go/services/";



/*$('#customerDetailPage').bind('pageinit', function(event) {
	getcouponListe(project_vars.custID, 'coupon');
	
});*/


function getstatistik(id, typ , color , bgcolor) {



	$.mobile.loading('show');

	$.getJSON(serviceURL + 'getstatistik.php', function(data) {

		// Zaehlen der gelieferten Daten Elemeneten
		//countcouponItems = countProperties(data.items);
		//console.log(countcouponItems);

		$('#newsItemListLi li').remove();


		statistik = data.items;
		//console.log(data);
		
		
		$.each(statistik, function(index, statistikItem) {
			
				/*$('#statistikItemListLi').append(

					'<h4 style="color:#843202;">' + statistikItem.ItemHeading  + ' - ' + statistikItem.Date4Item +   '</h4>' +
					'<p style="color:#843202;">' +  statistikItem.ItemDetails  + '</p>' + '<hr>' );
		*/

		$('#newsItemListLi').append('<li data-icon="info" style="background:' + bgcolor + ';"><a href="#" class="statListInternal" data-identifier="' + statistikItem.ID + '">' +
			
			'<h4 style="color:' + color + ' ;">' + statistikItem.ID + ' - ' + statistikItem.Kunde + '</h4>' +

			'<p style="color:' + color + ' ;"><strong>' +  statistikItem.Aufrufe + ' Aufruf(e) der app' + '</strong></p>' +

			'<span class="ui-li-count" style="color:' + color + ' ;">' + 'Statistik' + '</span>' +

			'</a></li>');

		
				//$('#debugInfo').append('debug -> user.Nr # ' + userItem.Nr + ' #<br> ');
				// $('#debugInfo').append('debug -> user.couponItem # ' + couponItem.couponItem + ' #<br> ');


			});

		

		$('#newsItemListLi').listview('refresh');

		

		$.mobile.loading('hide');


		
	});
}



// Anzahl objekte in json-file
function countProperties(obj) {
	var prop;
	var propCount = 0;

	for (prop in obj) {
		propCount++;
	}
	return propCount;
}
