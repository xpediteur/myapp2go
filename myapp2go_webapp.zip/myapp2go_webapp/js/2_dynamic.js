

//dynamic


var ListItemColor   = "#555960";
var ListItembgColor = "#FFFFFF";

// var custPicture       = "Inside_Logo320150.jpg";
