

//dynamic

var ListItemColor   = "#000000";
var ListItembgColor = "#FFFFFF";

// var custPicture       = "heigl_top.png";

