//dynamic


var ListItemColor   = "#000000";
var ListItembgColor = "#FFFFFF";

var global_advertising = true;