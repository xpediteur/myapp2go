
function getblogListe(id, typ , color , bgcolor) {

	if (global_appmodus === true) {

	var countobj = retrieveJSONData('modulesbuffer');
	
	var str_header = getJSONObject(countobj, 'blog') ; // headername holen aus JSON modulname

	$('#BlogListPageHeader').text(str_header); // Header name setzten

	}
	
	$.mobile.loading('show');

	$("#tableBlogs td").parent().remove();

	$.getJSON(serviceURL + 'getblogliste.php?id=' + id, function(data) {


		// $('#BlogListPageHeader').text(typ);


		$('#blogItemListLi li').remove();


		blogs = data.items;

		heute = new Date();

		var blogcount = countProperties(blogs);

		$('#blogcount').text( blogcount + ' Kommentare');

		
		var htmlContent= "";

		$.each(blogs, function(key, blogitem){

			var dateParts =  blogitem.date4blog.split("-");
			var jsDate = new Date(dateParts[0], dateParts[1] - 1, dateParts[2]);

			var beforedays = deltaDays(heute, jsDate );

			/*

			htmlContent+=('<tr class="row1"><td>'+blogitem.blogheading+   ' - schrieb '  +blogitem.blogername+'</td></tr>');

			htmlContent+=('<tr class="row2"><td>'+ '&nbsp; vor ' + beforedays + ' Tagen - '  + blogitem.date4blog+'</td></tr>');

			htmlContent+=('<tr class="row3"><td>'+blogitem.blogtext+'</td></tr>');
			
			*/


			$('#blogItemListLi').append('<li data-icon="false" style="background:' + bgcolor + ';"><a href="#" class="BlogListInternal"  data-identifierID="' + blogitem.ID +  '" >' +

				// '<img src="pics/' + 'status_invisible_40.png' + '" style="width:60px;height:60px;margin-left:8px;margin-top:15px;margin-bottom:5px;"/>' +

				'<h4 style="color:' + color + ' ;">' + blogitem.blogheading + '</h4>' +

				'<p style="color:' + color + ' ;">' + 'vor ' + beforedays + ' Tagen - '  + blogitem.date4blog + '</p>' +

				'<p style="color:' + color + ' ;">' +  'von '  + blogitem.blogername+ '</p>' +

				'<h5 style="color:' + color + ' ;">' + blogitem.blogtext + '</h5>' +

				'</a></li>');
		 
		});

		

		//$('#tableBlogs').find('tbody').append(htmlContent);

		$('#blogItemListLi').listview('refresh');


		$.mobile.loading('hide');


	});
}

// Anzahl objekte in json-file
function countProperties(obj) {
	var prop;
	var propCount = 0;

	for (prop in obj) {
		propCount++;
	}
	return propCount;
}


function deltaDays(date1, date2) {
    if(!date1 || !date2) return null;
    var check1 = new Date(date1.getFullYear(), date1.getMonth(), date1.getDate());
    var check2 = new Date(date2.getFullYear(), date2.getMonth(), date2.getDate());
    return Math.round(Math.abs(check1 - check2) / (1000 * 60 * 60 * 24 ));
}

