
$('#DocsDetailPage').on('pagebeforeshow', function(event) {

    $.mobile.loading('show');

    // Übergabe der ID, Bild, Text aus Liste
	var id         = project_vars.idMerker;
	var picname    = project_vars.picMerker;
	var detailtext = project_vars.DetailMerker;



	$('#docname').empty();
	$('#docPic').empty();
	$('#docdetail').empty();

	/*
	var htmldetail = detailtext.replace(/(\r\n|\n|\r)/gm, "<br />");

	htmldetail = htmlDecode(htmldetail);

	*/

	$('#docname').append(id);
	$('#docPic').attr('src', 'customerpics/' + picname);

	$('#docdetail').append(detailtext);

	//email - string für href aufbauen und setzten -> doc senden
	var mailrefferer = "mailto:empfäenger@eingeben.de?subject=myapp2go -  " + id + "&body=" + detailtext;

	$('#docsendmail').attr('href', mailrefferer);

	
	$.mobile.loading('hide');


});