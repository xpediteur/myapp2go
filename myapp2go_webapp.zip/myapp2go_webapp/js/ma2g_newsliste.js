
function getnewsListe(id, typ, color , bgcolor) {


	if (global_appmodus === true) {

	var countobj = retrieveJSONData('modulesbuffer');
	
	var str_header = getJSONObject(countobj, 'news') ; // headername holen aus JSON modulname

	$('#itemListPageHeader').text(str_header); // Header name setzten

	};

	
	$.mobile.loading('show');

	$.getJSON(serviceURL + 'getnewsliste.php?typ=' + typ + '&id=' + id, function(data) {

		
		$('#newsItemListLi li').remove();

		
		news = data.items;

		
		$.each(news, function(index, newsItem) {

			var htmldetail = newsItem.ItemDetails.replace(/(\r\n|\n|\r)/gm, "<br />");

			htmldetail = htmlDecode(htmldetail);


			$('#newsItemListLi').append('<li data-icon="arrow-d" style="background:' + bgcolor + ' ;"><a href="#" class="ItemListInternal" data-identifier="' + newsItem.ItemId + '"' + 'id="' + newsItem.u_date + '">' +

				'<h4 style="color:' + color + ' ;">' + newsItem.ItemHeading  + '</h4>' +

				'<p style="color:' + color + ' ;">' +  newsItem.Date4Itemnew + '</p>' +

				'<p style="color:' + color + ' ;">' +  htmldetail + '</p>' +

	/*			'<span class="ui-li-count" style="color: ' + color + ' ;">' + 'news' + '</span>' +  */

				'</a></li>');



			});


		$('#newsItemListLi').listview('refresh');


		$.mobile.loading('hide');



	});
}

// decode der Sonderzeichen =================================================================================================

function htmlDecode(value) {
	if (value) {
		return $('<div />').html(value).text();
	} else {
		return '';
	}
}
