
function getdocumentListe(id, typ , color , bgcolor) {


	if (global_appmodus === true) {

	var countobj = retrieveJSONData('modulesbuffer');
	
	var str_header = getJSONObject(countobj, 'docs') ; // headername holen aus JSON modulname

	$('#DocListPageHeader').text(str_header); // Header name setzten
	
	}

	var picname_merker = '';


	$.mobile.loading('show');

	$.getJSON(serviceURL + 'getdocumentliste.php?id=' + id, function(data) {

		
		$('#documentItemListLi li').remove();

	
		documents = data.items;

		//console.log(data);
		
		
		$.each(documents, function(index, documentItem) {


			var htmldetail = documentItem.ItemDetails.replace(/(\r\n|\n|\r)/gm, "<br />");

			htmldetail = htmlDecode(htmldetail);
			

			var split = documentItem.picname.split('.');

			var file          = split[0];
			var extension     = split[1];

			picname_merker = documentItem.picname;

			if (extension == 'pdf') {

				documentItem.picname = 'pdf_logo.png';

			}


		
			$('#documentItemListLi').append('<li data-icon="arrow-d" style="background:' + bgcolor + ';"><a href="#" class="DocumentListInternal"  data-identifierID="' + documentItem.ItemId + '"  data-identifier="' + documentItem.ItemHeading + '" data-identifierpic="' + picname_merker + '"  data-identifierdetail="' + documentItem.ItemDetails + '" >' +

				'<img src="customerpics/' + documentItem.picname + '" style="width:75px;height:75px;margin-left:3px;margin-top:3px;margin-bottom:5px;"/>' +

				'<h5 style="color:' + color + ' ;">' + documentItem.ItemHeading + '</h5>' +

				'<p style="color:' + color + ' ;">' +  htmldetail + '</p>' +

				'<span class="ui-li-count" style="color:' + color + ' ;">' + extension + '</span>' +

				'</a></li>');


				//$('#debugInfo').append('debug -> user.Nr # ' + userItem.Nr + ' #<br> ');
				// $('#debugInfo').append('debug -> user.couponItem # ' + couponItem.couponItem + ' #<br> ');


			});



$('#documentItemListLi').listview('refresh');



$.mobile.loading('hide');



});
}
