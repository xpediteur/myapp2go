// var serviceURL = "http://system3-consulting.de/myapp2go/services/";
 
// für dynamischen aufbau adminbereich 
function getmodulListeListview(id, typ , color , bgcolor) {
                 

    $.mobile.loading('show');


    $.getJSON(serviceURL + 'getmodules.php?id=' + id, function(data) {


                  $('#modul_cats li').remove();


                   modul = data.items;

                   $('#modul_cats').append('<li data-role="list-divider">Inhalt bearbeiten</li>');


                   $.each(modul, function(index, modulItem) {


                   $('#modul_cats').append('<li  style="background:' + bgcolor + ';"><a href="#" id="li_' + modulItem.modulclass  + '" data-identifier="' + modulItem.ID + '">'  + modulItem.modulname + ' bearbeiten' +


                                   // '<h5 style="color:' + color + ' ;">' + modulItem.modulname + '</h5>' +


                                   '</a></li>');


                                   });



                   $('#modul_cats').listview('refresh');


                   $.mobile.loading('hide');


    });
 
}
