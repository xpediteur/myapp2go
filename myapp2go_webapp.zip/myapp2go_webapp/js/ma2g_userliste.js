// var serviceURL = "http://system3-consulting.de/myapp2go/services/";



/*$('#customerDetailPage').bind('pageinit', function(event) {
	getcouponListe(project_vars.custID, 'coupon');
	
});*/


function getuserListe(id, typ , color , bgcolor) {

	
	$.mobile.loading('show');

	$.getJSON(serviceURL + 'getuserliste.php', function(data) {

		// Zaehlen der gelieferten Daten Elemeneten
		//countcouponItems = countProperties(data.items);
		//console.log(countcouponItems);

		$('#newsItemListLi li').remove();


		user = data.items;
		//console.log(data);
		
		
		$.each(user, function(index, userItem) {

			var custicon = userItem.ID + '_' + 'touch_icon57x57.png';
			
				/*$('#userItemListLi').append(

					'<h4 style="color:#843202;">' + userItem.ItemHeading  + ' - ' + userItem.Date4Item +   '</h4>' +
					'<p style="color:#843202;">' +  userItem.ItemDetails  + '</p>' + '<hr>' );
		*/

		$('#newsItemListLi').append('<li data-icon="arrow-d" style="background:' + bgcolor + ';"><a href="#" class="UserListInternal" data-identifier="' + userItem.ID + '">' +
			
			'<img src="pics/' + custicon + '" style="width:80px;height:80px;margin-left:3px;margin-top:3px;"/>' +

			'<h4 style="color:' + color + ' ;">' + userItem.ID + '  ' + userItem.Name1  + '</h4>' +

			'<p style="color:' + color + ' ;">' +  userItem.Name2 + '</p>' +

			'<p style="color:' + color + ' ;">' +  userItem.PLZ  +  ' ' + userItem.Ort + '</p>' +

			'<span class="ui-li-count" style="color:' + color + ' ;">' + 'user' + '</span>' +

			'</a></li>');

		
				//$('#debugInfo').append('debug -> user.Nr # ' + userItem.Nr + ' #<br> ');
				// $('#debugInfo').append('debug -> user.couponItem # ' + couponItem.couponItem + ' #<br> ');


			});

		

		$('#newsItemListLi').listview('refresh');

		

		$.mobile.loading('hide');


		
	});
}



// Anzahl objekte in json-file
function countProperties(obj) {
	var prop;
	var propCount = 0;

	for (prop in obj) {
		propCount++;
	}
	return propCount;
}
