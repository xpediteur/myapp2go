
function getcouponListe(id, typ , color , bgcolor) {

	if (global_appmodus === true) {

	var countobj = retrieveJSONData('modulesbuffer');
	
	var str_header = getJSONObject(countobj, 'coupon') ; // headername holen aus JSON modulname

	$('#itemListPageHeader').text(str_header); // Header name setzten

	}

	
	$.mobile.loading('show');

	$.getJSON(serviceURL + 'getnewsliste.php?typ=' + typ + '&id=' + id, function(data) {

		
		$('#newsItemListLi li').remove();

		
		coupon = data.items;
		//console.log(data);
		
		
		$.each(coupon, function(index, couponItem) {
			
			
		$('#newsItemListLi').append('<li data-icon="arrow-d" style="background:' + bgcolor + ';"><a href="#" class="ItemListInternal" data-identifier="' + couponItem.ItemId + '"' + 'id="' + couponItem.u_date +  '">' +
			
			'<h4 style="color:' + color + ' ;">' + couponItem.ItemHeading  + '</h4>' +

			'<p style="color:' + color + ' ;">' +  couponItem.Date4Itemnew + '</p>' +

			'<p style="color:' + color + ' ;">' +  couponItem.ItemDetails + '</p>' +

			// '<span class="ui-li-count" style="color:' + color + ' ;">' + 'coupon' + '</span>' +

			'</a></li>');

		
			
			});

		

		$('#newsItemListLi').listview('refresh');

		

		$.mobile.loading('hide');


		
	});
}
