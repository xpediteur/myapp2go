
function getstatistik_customer(id) {


	var iphone = 0;
	var ipad   = 0;
	var android = 0;
	var msie = 0;
	var chrome = 0;
	var firefox = 0;
	var sum_calls = 0;


	$.mobile.loading('show');

	$.getJSON(serviceURL + 'getstatistik_customer.php?id=' + id, function(data) {

		
		statistik = data.items;
		//console.log(data);
		
		
		$.each(statistik, function(index, statistikItem) {


			var device = statistikItem.info;

			if (device.toLowerCase().indexOf("iphone") != -1) {
				
				iphone++;

			}
			
			if (device.toLowerCase().indexOf("ipad") != -1) {
				
				ipad++;

			}

			if (device.toLowerCase().indexOf("android") != -1) {
				
				android++;

			}

			if (device.toLowerCase().indexOf("msie") != -1) {
				
				msie++;

			}

			if (device.toLowerCase().indexOf("chrome") != -1) {
				
				chrome++;

			}


			if (device.toLowerCase().indexOf("firefox") != -1) {
				
				firefox++;

			}

					
		$.mobile.loading('hide');
		
	});

	sum_calls = iphone + ipad + android + msie + chrome + firefox;

	var stat_html = 
	 		'<table data-role="table" id="movie-table-custom" data-mode="reflow" class="movie-list table-stroke">'+
			'<thead>  <tr> <th data-priority="1">Gerät</th> <th data-priority="2">Anzahl</th>  </tr> </thead>' +
				'<tbody> <tr> <th>iphone</th>  <td>' + iphone + '</td> </tr>' +
				'<tbody> <tr> <th>ipad</th>    <td>' + ipad + '</td> </tr>' +
				'<tbody> <tr> <th>android</th> <td>' + android + '</td> </tr>' +
				'<tbody> <tr> <th>msie</th>    <td>' + msie + '</td> </tr>' +
				'<tbody> <tr> <th>chrome</th>  <td>' + chrome + '</td> </tr>' +
				'<tbody> <tr> <th>firefox</th> <td>' + firefox + '</td> </tr>' +
				'<tbody> <tr> <th>Gesamt</th> <td>'  + sum_calls + '</td> </tr>' +
			'</tbody> </table> <br>';

			// dynamic content setzten
		 $('#dynamic_content').html('<h4>Statistik der Aufrufe der apps</h4>');	
		 $('#dynamic_content').append(stat_html).trigger('create');


});

}


// Anzahl objekte in json-file
function countProperties(obj) {
	var prop;
	var propCount = 0;

	for (prop in obj) {
		propCount++;
	}
	return propCount;
}
