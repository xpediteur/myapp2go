

//dynamic

var ListItemColor   = "#555960";
var ListItembgColor = "#FFFFFF";

// var custPicture       = "heigl_top.png";

