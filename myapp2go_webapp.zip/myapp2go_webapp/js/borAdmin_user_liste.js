// var serviceURL = "http://system3-consulting.de/JQMBOR/services/";

var user;

 function getuserListe() {

 	$.mobile.loading('show');

 	$.getJSON(serviceURL + 'getuserliste.php', function(data) {

 		$('#tourList li').remove();
 		$('#userList li').remove();

 		user = data.items;
		//console.log(data);
		// $('#tourList').append('<li><a href="userdetails.html?id=' + tour.Nr + '">' +

			$.each(user, function(index, user) {
				$('#userList').append('<li style="background: white;"><a href="#" class="userListInternal" data-identifier="' + user.ID + '">' +
					'<img src="pics/customers.png' + '"/>' +
					'<h5>' + user.email + '</h5>' +
					'<p style="color:#808080;">' + 'Info : ' +  user.logInfo + '</p>' +
					'<p style="color:#808080;">' + 'Aktiv: ' + user.aktiv + '</p>' +
					'<p style="color:#808080;">' + 'Passwort: ' + user.passwort + '</p>' +
					'<span class="ui-li-count" style="color: red;">' + 'delete' + '</span></a></li>');
			});

			$('#userList').listview('refresh');

			$.mobile.loading('hide');

			
		});
}
