
// VALIDATION  ===========================================================================================================
// validate item insert  =================================================================================================
$(document).ready(function(){
  $("#ma2gAdmin_item_insert").validate({

    messages: {
      heading: "Überschrift muss eingegeben werden",
      detail: "Detail muss eingegeben werden",
      date: "Bitte Datum im Format jjjj-mm-dd eingeben"

    },

    rules:{

      date : {
        date : true
      }


    },

    errorPlacement: function (error, element) {
            if (element.is('input')) {
                error.insertAfter(element.parent());
            }
            else
            {
                error.insertAfter(element);
            }
    },

    submitHandler: function(form) {

      call_ajax_item_insert();

    }
  });
});

// validate pw change  =================================================================================================
$(document).ready(function(){
  $("#ma2gAdmin_pw_change").validate({


    messages: {
      password: "Passwort muss eingegeben werden",
      
      password2: "Gleiches Passwort muss eingegeben werden"

    },

    rules:{

      password :"required",
      password2:{
        equalTo: "#password"
      }


    },

    errorPlacement: function (error, element) {
            if (element.is('input')) {
                error.insertAfter(element.parent());
            }
            else
            {
                error.insertAfter(element);
            }
    },

    submitHandler: function(form) {

       call_ajax_pw_change();

    }
  });
});

