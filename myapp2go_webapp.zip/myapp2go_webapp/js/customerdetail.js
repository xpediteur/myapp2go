
function displayContacts(){

	//$('#customerDetailPage').on('pageinit', function(event) {

	$.getJSON(serviceURL + 'getcustomer.php?id=' + global_preinstalled_custID  , storeCustomerDetail);


	//window.setInterval(shownews, 10000);
		
	}


// customerdetail Infotext anzeigen =========================================================================================
function storeCustomerDetail(data){

	storeJSONData(data, 'customerdetailbuffer');
	
}

// customerdetail Infotext anzeigen =========================================================================================
function displayCustomerDetail(storename){

	
	var tmpData = retrieveJSONData(storename);


	var customer = tmpData.item;


	// adpic setzen

	//$('#adPic').css("opacity", 0);

	//$('#adPic').attr('src', 'pics/denk_bike_outdoor.jpg').fadeIn(1000);

	//LOGO setzten 
	$('#custPic').attr('src', 'pics/' + customer.Picture);


	$('#button_wrapper').show();

	var htmlinfotext = customer.InfoText.replace(/(\r\n|\n|\r)/gm, "<br />");

	var htmlimpressum = customer.Impressum.replace(/(\r\n|\n|\r)/gm, "<br />");

	var new_name1 = htmlDecode(customer.Name1);
	var new_name2 = htmlDecode(customer.Name2);

	localStorage['customerName'] = new_name1;      // global merken
	

	// title setzten
	document.title = customer.NameZusatz;

	//Name - string für aufbauen und setzten	
	$('#custname1').text(new_name1);
	$('#custname2').text(new_name2);

	$('#bt_custinfo .ui-btn-text').text(new_name1);


	//URL - string für aufbauen und setzten 
	$('#bt_custURL .ui-btn-text').text(customer.URL);

	$('#bt_custURL').attr('href', customer.URL);

	
	//email - string für href aufbauen und setzten 
	var mailrefferer = 'mailto:' + customer.Email;
	$('#bt_sendmail').attr('href', mailrefferer);
	$('#bt_sendmail .ui-btn-text').text(customer.Email);


	//tel - string für href aufbauen und setzten 
	var telrefferer = 'tel:' + customer.Phone;
	$('#bt_tel').attr('href', telrefferer);
	$('#bt_tel .ui-btn-text').text(customer.Phone);


	// Impressum und Info füllen
	$('#custinfodetail').empty();
	$('#custImpressum').empty();


	//LOGO auf Infoseite setzten 
	$('#custinfoPic').attr('src', 'pics/' + customer.Picture);

	$('#custinfodetail').html(htmlinfotext);
	$('#custinfodetail').trigger('create');


	$('#custImpressum').append(htmlimpressum);

	// facbook like
	if (customer.facebookstr) {

		showSocialButtonsfb(customer.facebookstr);

	}

	// google maps / coordinaten merken
	var split = customer.googlemapsstr.split(',');

	var lat     = split[0];
	var lng     = split[1];

	localStorage['lat']  = lat;
	localStorage['lng']  = lng;	

    /*
	
	$('#googlemaps-karte').html(customer.googlemapsstr);
	$('#googlemaps-karte').trigger('create');
	
	*/

	// $(document).trigger("ajaxdone");
		
};


// decode der Sonderzeichen =================================================================================================

function htmlDecode(value) {
	if (value) {
		return $('<div />').html(value).text();
	} else {
		return '';
	}
}

// timer news ==============================================================================================================
function shownews() {

	alert(' neue news alle 10 sec. ');

}



// ajax ende funktion nur einmal ausführen ==============================================================================
$(document).ajaxStop(function(){


		if (typeof(togglecustInfo) == "undefined" ){

			//setzten des aktuellen Status nur beim ersten mal aufrufen
			$('#custInfoToggle').attr('data-search', 'off');

		}

		togglecustInfo = $('#custInfoToggle').attr('data-search');

		if (togglecustInfo == 'off' ){



				console.log( 'all ajax XHR ended ');

			displayCustomerDetail('customerdetailbuffer');

				console.log( 'display customerdetail ');

			displayModulesDetail('modulesbuffer');

				console.log( 'display modules ');

			displayCounter('counterbuffer');

				console.log( 'display counter ');

			// trackerdaten schreiben
			writetracker(global_preinstalled_custID);

				console.log( 'write tracker ');



			$('#custInfoToggle').attr('data-search', 'on');
		}
});

function cycleImages() {
    $('#banner_cycler').each(function() {
        var $active = $(this).find('.active');
        var $next = ($(this).find('.active').next().length > 0) ? $(this).find('.active').next() : $(this).find('img:first');
        $next.css('z-index', 2); //move the next image up the pile
        $active.fadeOut(1500, function() { //fade out the top image
            $active.css('z-index', 1).show().removeClass('active'); //reset the z-index and unhide the image
            $next.css('z-index', 3).addClass('active'); //make the next image the top one
        });
    });
}


