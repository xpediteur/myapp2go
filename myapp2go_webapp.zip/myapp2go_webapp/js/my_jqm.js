// Initialisierungen ============================================================================================================
// ==============================================================================================================================

var serviceURL  = "http://www.m.myapp2go.de/services/";

var baseURL     = "http://www.m.myapp2go.de/";

var redirecturl = baseURL + 'ma2gAdmin.html'; // !!!!! url - wird fix gesetzt !!!!!

// globale variablen setzten ====================================================================================================

var global_preinstalled_custID = dynamic_Userid; // !!!!! UserId - wird dyn. gesetzt, kommt aus x_dynamic.js !!!!!

// globale variablen setzten ====================================================================================================
// ==============================================================================================================================

project_vars = {};

var global_advertising;

var global_appmodus = true;



var togglecustInfo;

var toggleSearchItem;

var toggleSearchDoc;


project_vars.geolocation = 'on'; // Standardeistellung

localStorage['debug'] = '### debug Rel. 1.0 build 020j  ### <hr> ' ;

// ==============================================================================================================================

$( document ).on( "mobileinit", function() {

    // phonegap settings

    $.mobile.allowCrossDomainPages = true;
    $.mobile.phonegapNavigationEnabled = true;
    $.mobile.ajaxEnabled = false;

    console.log('in mobileinit ');


    localStorage['debug'] += 'debug -> global_preinstalled_custID # ' + global_preinstalled_custID + ' #<br> ';



  });

// $.mobile.page.prototype.options.domCache = true;


$.mobile.loader.prototype.options.textVisible = true;

$.mobile.page.prototype.options.backBtnText = "zur&uuml;ck";

$.mobile.page.prototype.options.addBackBtn = true;

$.mobile.popup.prototype.options.history = false;


$.mobile.loadingMessage = "Daten laden ... ";



// INITALISIERUNG counter etc. auf Startseite erstellen - ooder pageinit=========================================================
// ==============================================================================================================================
$('#customerDetailPage').on('pagebeforecreate', function(event) {

//  $('#custPic').attr('src', 'pics/' + custPicture); 

// buttons hidden 
$('#button_wrapper').hide();

// Contact Buttons anzeigen, Impressunm und About füllen
displayContacts();

// Module li aufbauen
build_modules(global_preinstalled_custID);

// counter holen anzeigen
getCounter();


localStorage['debug'] += 'debug -> global_preinstalled_custID # ' + global_preinstalled_custID + ' #<br>  ';


// blinkende Anzahl
/*setInterval("$('#newsCount').toggle();",500);
  setInterval("$('#eventCount').toggle();",500);
  */

  setInterval("$('#couponCount').toggle();",500);


  if ( project_vars.geolocation == 'on') {

    getLocation();

  }


});

// counter anzeigeb, bei pageshow wird refresh gemacht , vorher pagebeforecreate================================================
$('#customerDetailPage').on('pageshow', function(event) {

 /*   if (global_preinstalled_custID != 10015) {

      $('#ads_header').hide();

    }


  if (global_preinstalled_custID == 10015) {
  // run every 5s
    setInterval('cycleImages()', 5000);
    
  }

*/
  // getCounter();

  /* var $main_content = $("#customerDetailPage div:jqmData(role=content)");

   var cheight = getRealContentHeight();

   $main_content.height(cheight);

   console.log (cheight);

   */


 });

// myapp2go werbeseite set color===============================================================================================
/*$(document).delegate("#myapp2goInfoPage", "pagecreate", function () {

  $(this).css('background', '#FFFFFF');//`this` refers to `#pageDetail`

       //LOGO setzten 
  $('#myapp2goInfoPic').attr('src', 'pics/myApp2go_RGB_320x73');

  $('#myapp2goinfodetail').load('templates/tmpl_myapp2go.html').trigger("create");

});*/


// myapp2go werbeseite ========================================================================================================

$(document).delegate("#myapp2goInfoPage", "pagebeforeshow", function () {

/*$('#myapp2goInfoPage').on('pagecreate', function(event) {
*/
  $(this).css('background', '#FFFFFF');//`this` refers to `#pageDetail`

       //LOGO setzten 
  $('#myapp2goInfoPic').attr('src', 'pics/myApp2go_RGB_320x73');

  $('#myapp2goinfodetail').load('templates/tmpl_myapp2go.html').trigger("create");

 //

 });

// =============================================================================================================================
$('#customerDetailPage').on("pageinit", function() {



 //toast('INFORMATION <hr> aktuelle Neuigkeiten vorhanden ... ');

});


// photoswipe init =============================================================================================================

var initPS = function(){

  $(document).ready(function() { console.log('script start'); var myPhotoSwipe = $("#customgallery a").photoSwipe( { enableMouseWheel: false , enableKeyboard: false }); });

};

// =============================================================================================================================

$('#imageflip').on('pagebeforeshow', function() {

  getPictures(global_preinstalled_custID);


});

// =============================================================================================================================

// google maps anzeigen =====================================================================================================
$('#anfahrt').on('pageshow', function(event) {
//$("#anfahrt").bind ("click", function (event){

 if ( project_vars.geolocation == 'on') {

   displayDistance(localStorage['lat'], localStorage['lng']);

 }

 var lat = localStorage['lat'];
 var lng = localStorage['lng'];

 var latlng = new google.maps.LatLng (lat, lng);
 var options = {
  zoom : 16,
  center : latlng,
  mapTypeId : google.maps.MapTypeId.ROADMAP
};

var $content = $("#anfahrt div:jqmData(role=content)");
$content.height (screen.height - 50);
var map = new google.maps.Map ($content[0], options);


$.mobile.changePage("#anfahrt");



new google.maps.Marker (
{
  map : map,
  animation : google.maps.Animation.DROP,
  position : latlng
});


});

// google maps anzeigen alert mit entfernung ===============================================================================
$('#anfahrt').on('pagebeforehide', function(event) {

  if ( project_vars.geolocation == 'on') {

    var aktCustomer = localStorage['customerName'];

    var message = '... nur ' +  localStorage['geoEntfernung'] + ' km zu ' + aktCustomer + ', los gehts !';

    toast(message);
  }


});

// =============================================================================================================================

// pdfinit -- ooder pageinit

$('#pdfpage').on('pageshow', function(event) {

 var $pdfcontent = $("#pdfpage div:jqmData(role=content)");
 
 
 console.log($pdfcontent);

 // docs viewer aufrufen
 $('.embed').gdocsViewer();

 $('.gdocsviewer iframe').css("width", "100%");
//$('.gdocsviewer iframe').css("height", "100%");

$pdfcontent.css("padding", "0px");

$pdfcontent
.height(
  $(window).height() - (5 + $('#pdfpage div:jqmData(role=header)').last().height()  + $('#pdfpage div:jqmData(role=footer)').last().height()) );



// alert ($pdfcontent['context'].height);



});


/*
$('#itemListPage').bind('pagebeforehide', function (event, ui)
{
 alert ("leaving itemListPage");
});
*/

// module anzeigen =======================================================================================================
function build_modules(id) {

  $.mobile.loading('show');


  $.getJSON(serviceURL + 'getmodules.php?id=' + id, storeModules);

}

// customerdetail Infotext anzeigen =========================================================================================
function storeModules(data){

  storeJSONData(data, 'modulesbuffer');
  
}


// module anzeigen =======================================================================================================
function displayModulesDetail(storename){


  $('#modul_cats li').remove();

  var tmpData = retrieveJSONData(storename);

  modul = tmpData.items;

    //console.log(data);
    

    $.each(modul, function(index, modulItem) {

      if (modulItem.modulcounter == 1) {

        $('#modul_cats').append('<li><a href="#" class="' + modulItem.modulclass + '">' +

          '<h5>' + modulItem.modulname + '</h5>' +

          '<span class="ui-li-count">' +

          '<div id="' + modulItem.modulclass +'Count"></div>' +

          '</span></a></li>');

      }

      else{

        $('#modul_cats').append('<li><a href="#" class="' + modulItem.modulclass + '">' +

          '<h5>' + modulItem.modulname + '</h5>' +

          '<div id="' + modulItem.modulclass +'Count"></div>' +

          '</a></li>');

      }

    });


    $('#modul_cats').listview('refresh');



  }

// counter holen =======================================================================================================

function getCounter() {

  $.getJSON(serviceURL + 'getcounter.php?id=' + global_preinstalled_custID, storeCounter);

}


// counter storen =========================================================================================
function storeCounter(data){

  storeJSONData(data, 'counterbuffer');
  
}

// counter anzeigen =======================================================================================================

function displayCounter(storename) {

  var news_anz = 0;
  var event_anz = 0;
  var coupon_anz = 0;
  var document_anz = 0;
  

  var tmpData = retrieveJSONData(storename);

  counter = tmpData.items;


  if (counter) {


  //console.log(data);

  
  $.each(counter, function(index, counterItem) {

   if(counterItem.ItemTyp == 'News'){

     news_anz = counterItem.count;

   }

   if(counterItem.ItemTyp == 'Event'){

     event_anz = counterItem.count;

   }

   if(counterItem.ItemTyp == 'Coupon'){

    coupon_anz = counterItem.count;

  }

  if(counterItem.ItemTyp == 'Document'){

    document_anz = counterItem.count;

  }

  
});


  $('#newsCount').text(news_anz);

  $('#eventsCount').text(event_anz);

  $('#couponCount').text(coupon_anz);

  $('#docsCount').text(document_anz);


}

};


// counter anzeigen ende ===================================================================================================

// scroll to top
$('#uptotop').on('click', function() {

 $('body').animate({scrollTop: '0px'}, 500, function(){ $('body').clearQueue(); });

});


// app cache status anzeigen
/*$('#tourListPage').live('pageshow', function(event) {

  checkCacheVersion();

});
*/

// cache prüfen =================================================================================================================
function checkCacheVersion(){
  var webappCache = window.applicationCache;

  $('#debugInfo').append('debug -> webappCache # ' + webappCache.status + ' #<br>  ');

  if(webappCache){

        //0-> unchached
        //1-> idle
        //2-> checking
        //3-> downloading
        //4-> updateready

        //console.log('Cache state= ' +  webappCache.status);

        //alert('Cache state = ' +  webappCache.status);

        if(webappCache.status == window.applicationCache.UPDATEREADY){
          console.log('[Cache] There is an update waiting for reload');
          webappCache.swapCache();
          location.reload();
        }
      }
    }


// ===  click auf li listeneintrag in items auswerten und sprung auf detailpage ========================================================

$('#newsItemListLi').on('click', 'a' , function (event) {


 var tbool;

 tbool = $(this).hasClass('ItemListInternal ui-link-inherit');

 if (tbool) {
     //
   }


   var aktItemID = $(this).jqmData('identifier');

   project_vars.idMerker   = aktItemID;
   localStorage['itemid']  = aktItemID;

   $.mobile.changePage( "#ItemDetailPage", { transition: "slidedown"} );


 });


$('#documentItemListLi').on('click', 'a' , function (event) {


alert ( 'in doclist' );

});

$('#newsItemListLi').on('click', 'a' , function (event) {

alert ( 'in newslist' );

var tbool_item = $(this).hasClass('ItemListInternal ui-link-inherit');

if (tbool_item) {

alert (' news class');

};

});




// ===  click auf li listeneintrag in documente auswerten und sprung auf detailpage ========================================================

$('#documentItemListLi').on('click', 'a' , function (event) {


 var tbool;

 tbool = $(this).hasClass('DocumentListInternal ui-link-inherit');

 if (tbool) {

     // identifier auswerten und merken

     var aktItemID = $(this).jqmData('identifier');
     var aktPicID =  $(this).jqmData('identifierpic');
     var aktDetail = $(this).jqmData('identifierdetail');

     project_vars.idMerker     = aktItemID;
     project_vars.picMerker    = aktPicID;
     project_vars.DetailMerker = aktDetail;

   // console.log (   project_vars.idMerker + ' / ' +  project_vars.picMerker ); 

   localStorage['itemid']  = aktItemID;
   localStorage['picid']   = aktPicID;
   localStorage['detail']   = aktDetail;


   var split = aktPicID.split('.');

   var pname          = split[0];
   var pextension     = split[1];

   if (pextension == 'pdf') {

    // pdf viewer aufrufen
    $('a.embed').attr('href', baseURL +  'customerpics/' + aktPicID);

    $.mobile.changePage( "#pdfpage", { transition: "slidedown"} );

  }else{

    $.mobile.changePage( "#DocsDetailPage", { transition: "slidedown"} );

  }

}

});



// ===  click auf li listeneintrag in movie  auswerten und sprung auf detailpage ========================================================

$('#movieItemListLi').on('click', 'a' , function (event) {


 var tbool;

 tbool = $(this).hasClass('MovieListInternal ui-link-inherit');

 if (tbool) {

     // identifier auswerten und merken

     var aktMovieheader = $(this).jqmData('identifier');
     var aktMovieID =  $(this).jqmData('identifierpic');
     var aktMovieDetail = $(this).jqmData('identifierdetail');

       // console.log (   project_vars.idMerker + ' / ' +  project_vars.picMerker ); 

       localStorage['movieheader']    = aktMovieheader;
       localStorage['movieid']        = aktMovieID;
       localStorage['moviedetail']    = aktMovieDetail;


       var split = aktMovieID.split('.');

       var pname          = split[0];
       var pextension     = split[1];

       $.mobile.changePage( "#movie-screen", { transition: "slidedown"} );


     }

   });



// ===  click auf li listeneintrag in menu auswerten und sprung auf detailpage ========================================================

$('#modul_cats').on('click', 'a' , function (event) {


 var innews   = $(this).hasClass('news ui-link-inherit');

 var inevents = $(this).hasClass('events ui-link-inherit');

 var incoupon   = $(this).hasClass('coupon ui-link-inherit');

 var indocs   = $(this).hasClass('docs ui-link-inherit');

 var ingallery   = $(this).hasClass('gallery ui-link-inherit');

 var inmovie   = $(this).hasClass('movie ui-link-inherit');

 var inblog   = $(this).hasClass('blog ui-link-inherit');


        if (innews){


          //alert( 'in jqm:: li a click event -> :: in news BT click');

          
          project_vars.actTyp = 'news';

          $.mobile.changePage( "#itemListPage", { transition: "slidefade"} );

          getnewsListe(global_preinstalled_custID, 'News', ListItemColor, ListItembgColor);

          //$('#top_button').append('<a id="uptotop" data-role="button" class="ui-btn-right" data-mini="true" data-icon="arrow-u" data-theme="a">Top</a>');

        }

        if (inevents){


          //alert( 'in jqm:: li a click event -> :: in event BT click');

          project_vars.actTyp = 'events';

          $.mobile.changePage( "#itemListPage", { transition: "slidefade"} );

          geteventListe(global_preinstalled_custID, 'Event', ListItemColor, ListItembgColor);

        }


        if (incoupon){


          //alert( 'in jqm:: li a click event -> :: in event BT click');

          project_vars.actTyp = 'coupon';

          $.mobile.changePage( "#itemListPage", { transition: "slidefade"} );

          getcouponListe(global_preinstalled_custID, 'Coupon', ListItemColor, ListItembgColor);

          
        }

        if (indocs){


          //alert( 'in jqm:: li a click event -> :: in event BT click');

          project_vars.actTyp = 'docs';

          $.mobile.changePage( "#documentListPage", { transition: "slidefade"} );

          getdocumentListe(global_preinstalled_custID, 'Document', ListItemColor, ListItembgColor);

          
        }

        if (ingallery){


          //alert( 'in jqm:: li a click event -> :: in event BT click');

          project_vars.actTyp = 'gallery';

          //getPictures(global_preinstalled_custID  );

          $.mobile.changePage( "#imageflip", { transition: "slidefade"} );

          
        }


        if (inmovie){


          //alert( 'in jqm:: li a click event -> :: in event BT click');

          project_vars.actTyp = 'movie';

          $.mobile.changePage( "#movieListPage", { transition: "slidefade"} );

          getmovieListe(global_preinstalled_custID, 'Movie', ListItemColor, ListItembgColor);

          
        }

         if (inblog){


          //alert( 'in jqm:: li a click event -> :: in event BT click');

          project_vars.actTyp = 'blog';

          $.mobile.changePage( "#idblog", { transition: "slidefade"} );

          
          getblogListe(global_preinstalled_custID, 'Blog', ListItemColor, ListItembgColor);
          
        }



      });

/*

$('#demo-page').on('pagebeforeshow', function(event) {

$('a.media').media(function(el, options) {
      options.caption = false;
      options.height = 800;
      options.bgColor = 'transparent';
      options.width = 320;
      options.allowfullscreen = 'true';
    });

 });


*/
// $ajax - user registrieren ===========================================================================================
function onSuccess(data, status)
{
  data = $.trim(data);
  $("#notification").text(data);
}

function onError(data, status)
{
  data = $.trim(data);
  $("#notification1").text(data);
}


// function zum Bilder holen ====================================================================================================
function getPictures(userid) {

  var serviceURL_pic = serviceURL + 'getGalleryPics.php';

  //console.log(userid);

  $.ajax({
    type: "POST",
    url: serviceURL_pic,
    cache: false,
    data: {nr : userid},
    success: onSuccess_pic,
    error: onError_pic
  });

  return false;

}

// $ajax - bilder holen fallback ============================================================================================
function onSuccess_pic(data, status)
{
  
  data = $.trim(data);


  var countobj = retrieveJSONData('modulesbuffer');
  
  var str_header = getJSONObject(countobj, 'gallery') ; // headername holen aus JSON modulname

  $('#GalleryListPageHeader').text(str_header); // Header name setzten



  if (data) {
    $('#customgallery').empty();
    $('#customgallery').children().remove('li');
  // $('#customgallery').append('<li><a href="customerpics/1_heigl_k_7.jpg" rel="external"><img src="customerpics/_1_heigl_k_7.jpg" alt="- Praxis - Bild 1"></a></li>');
  
  $('#customgallery').append(data);
  
  console.log('inserted');

  $('#customgallery').trigger('listviewcreate');

  initPS();

  console.log('scripted');

  

} else{


  $('#customgallery').empty();
  $('#customgallery').append('<h5>keine Bilder vorhanden</h5>');


  
}

};


function onError_pic(data, status)
{
  //$("#notification").text("Fehler!");

  alert(data);
}

//  $ajax - blog neu =================================================================================================
$(document).ready(function() {
  $("#ma2g_blog_insert #submit").click(function(){


    // input hidden zu form hier custID
    $('<input>').attr({
      type: 'hidden',
      value: global_preinstalled_custID,
      name: 'cid'
    }).appendTo('#ma2g_blog_insert');


    var serviceURL_blog = serviceURL + 'ma2g_blog_insert.php';

    var formData = $("#ma2g_blog_insert").serialize();

    // console.log(formData);

    $.ajax({
      type: "POST",
      url: serviceURL_blog,
      cache: false,
      data: formData,
      success: onSuccess,
      error: onError
    });

     $('#ma2g_blog_insert').trigger("reset");

    return false;

  });
});


// suche anzeigen handeln bei Itempage ========================================================================================

$('#btSearchitem').on('click', function() {


  if (typeof(toggleSearchItem) == "undefined" ){

  //setzten des aktuellen Status
  $('#btSearchitem').attr('data-searchitem', 'off');

}


// holen des akt. Status
toggleSearchItem = $('#btSearchitem').attr('data-searchitem');


if (toggleSearchItem == 'off' ){

  $(".ui-listview-filter").remove();

  $('#newsItemListLi').listview('option', 'filter', true);
  $('#newsItemListLi').listview('refresh');
  $('#newsItemListLi').trigger("listviewcreate");



  $('#btSearchitem').attr('data-searchitem', 'on');

}

if (toggleSearchItem == 'on'){

  $(".ui-listview-filter").remove();

  $('#newsItemListLi').listview('option', 'filter', false);
  $('#newsItemListLi').listview('refresh');
  $('#newsItemListLi').trigger("listviewcreate");


  $('#btSearchitem').attr('data-searchitem', 'off');


}


});

// suche anzeigen handeln bei Docs page ========================================================================================

$('#btSearchdoc').on('click', function() {


  if (typeof(toggleSearchDoc) == "undefined" ){

  //setzten des aktuellen Status
  $('#btSearchdoc').attr('data-searchdoc', 'off');

}


// holen des akt. Status
toggleSearchDoc = $('#btSearchdoc').attr('data-searchdoc');


if (toggleSearchDoc == 'off' ){

  $(".ui-listview-filter").remove();

  

  $('#documentItemListLi').listview('option', 'filter', true);
  $('#documentItemListLi').listview('refresh');
  $('#documentItemListLi').trigger("listviewcreate");

  $('#btSearchdoc').attr('data-searchdoc', 'on');

}

if (toggleSearchDoc == 'on'){

  $(".ui-listview-filter").remove();



  $('#documentItemListLi').listview('option', 'filter', false);
  $('#documentItemListLi').listview('refresh');
  $('#documentItemListLi').trigger("listviewcreate");

  $('#btSearchdoc').attr('data-searchdoc', 'off');


}


});

// =============================================================================================================================
function getLocation(){

  navigator.geolocation.getCurrentPosition(function(position){

   console.log('akt. Latitude: '+position.coords.latitude+' / akt. Longitude: '+position.coords.longitude);
   
   //alert('Latitude: '+position.coords.latitude+' / Longitude: '+position.coords.longitude);

   // akt. Standort speichern
   project_vars.latitude = position.coords.latitude;
   project_vars.longitude = position.coords.longitude;


   localStorage['debug'] +=  'debug -> project_vars.latitude # ' + project_vars.latitude + ' #<br>  ';
   localStorage['debug'] += 'debug -> project_vars.longitude # ' + project_vars.longitude + ' #<br> ';

 });
};

// =============================================================================================================================
function showSocialButtonsfb(curl) {

  if (curl) {

    var html =
    '<div id="social-buttons" class="fadeable fade">'
    + '<div class="fb-like" data-href="' + curl + '" data-layout="standard" data-width="150" ></div>'
    + '<div id="fb-root"></div>'
    + '</div>';

    window.fbAsyncInit = function() {
    // init the FB JS SDK
    FB.init({
      appId      : 232348106918820,                      // App ID from the app dashboard
      channelUrl : 'http://m.myapp2go.de/facebook_ch.html',           // Channel file for x-domain comms
      status     : true,                                 // Check Facebook Login status
      xfbml      : true                                  // Look for social plugins on the page
    });

    // Additional initialization code such as adding Event Listeners goes here
  };


  document.getElementById( 'viewport' ).insertAdjacentHTML( 'beforeEnd', html );

  var script = document.createElement( 'script' );
  script.async = true;
  script.src = document.location.protocol + '//connect.facebook.net/de_DE/all.js';
  document.getElementById( 'fb-root' ).appendChild( script );

  window.setTimeout( function () {

    document.getElementById( 'social-buttons' ).removeAttribute( 'class' );

  }, 100 );

};


};

// =============================================================================================================================
function isiPhone(){
  return (
        //Detect iPhone
        (navigator.platform.indexOf("iPhone") != -1) ||
        //Detect iPod
        (navigator.platform.indexOf("iPod") != -1)
        );
}

// ==============================================================================================================================

//  buttons  click !!!

$('#bt_debug').click(function(){

  toast( localStorage['debug']);

  //$.mobile.changePage( "#iddashboard", { transition: "pop"} );
 

});


$('#refreshblog').click(function(){

  getblogListe(global_preinstalled_custID, 'Blog', ListItemColor, ListItembgColor);

  //$.mobile.changePage( "#iddashboard", { transition: "pop"} );
 

});

$('#btSort').on("click", function(){

  $('ul#newsItemListLi>li').tsort('a',{order:'asc',attr:'id'});

  
});



// qr code button - code erstellen und anzeigen ===========================================================================
$('#bt_qrcode').click(function(){

 getqrcode();


 var picname = global_preinstalled_custID + '_' + 'qrfile.png';


 $.mobile.changePage( "#qr-display", { transition: "pop"} );

  //QR setzten 
  $('#qrpic').attr('src', 'customerpics/' + picname);
  $('#qrcode').trigger('create');

  var ma2g_link = 'http://www.m.myapp2go.de/?id=' + global_preinstalled_custID;

  var xlink = escape(ma2g_link);

  //email - string für href aufbauen und setzten -> senden
  var mailrefferer = "mailto:empfäenger@eingeben.de?subject=myapp2go - die mobile app von " + localStorage['customerName'] + "&body=" + 'Hier gehts zur app ' + xlink;

  $('#qrsendmail').attr('href', mailrefferer);

  
});


// ==============================================================================================================================

function displayDistance(customerlat, customerlng) {


  var geoEntfernung = 0;

  if ( project_vars.geolocation == 'on') {

    // Standort als variable
    var p1 = new google.maps.LatLng(project_vars.latitude, project_vars.longitude);

    // var p2 = new google.maps.LatLng(48.6608015, 13.622212699999999 );
    var p2 =  new google.maps.LatLng(customerlat, customerlng);

    console.log(customerlat + ' / ' + customerlng);
    
    // berechnen
    geoEntfernung = calcDistance(p1,p2);

    console.log( 'berechnete Entfernung: ' +  geoEntfernung);

    localStorage['geoEntfernung'] = geoEntfernung;

  } else { 

    localStorage['geoEntfernung'] = 'Entfernung nicht berechenbar';

  }
}

//calculates distance between two points in km's ================================================================================
function calcDistance(p1, p2){

  return (google.maps.geometry.spherical.computeDistanceBetween(p1, p2) / 1000).toFixed(2);

}
// popup  ========================================================================================================================
var toast=function(msg){
  $("<div class='ui-loader ui-overlay-shadow ui-body-d ui-corner-all' ><h5>"+msg+"</h5></div>")
  .css({ display: "block",
    opacity: 0.90, 
    position: "fixed",
    padding: "7px",
    color: "grey",
    "text-align": "center",
    width: "270px",
    left: ($(window).width() - 284)/2,
    top: $(window).height()/2 })
  .appendTo( $.mobile.pageContainer ).delay( 4000 )
  .fadeOut( 400, function(){
    $(this).remove();
  });
};

$('#bt_test').on('click', function() {

  toast('aktuelle Neuigkeiten vorhanden ... ');

});

// create movie=============================================================================================================

$('#movie-screen').on('pageshow', function() {

  $('#movie-content').empty();

  $('#moviename').empty();

  $('#moviedetail').empty();
  


// var $moviecontent = $("#movie-content div:jqmData(role=content)");

// $('#movie-content').height(400);

// $('#example_video_test').height(264);


var obj,
source;


obj = document.createElement('video');
$(obj).attr('id', 'example_video_test');
$(obj).attr('class', 'video-js vjs-default-skin');
$(obj).attr('width', '290');
$(obj).attr('data-height', '264');
$(obj).attr('controls', ' ');
$(obj).attr('preload', 'auto');
$(obj).attr('autoplay', 'true');
$(obj).attr('data-setup', '{}');

source = document.createElement('source');
$(source).attr('type', 'video/mp4');
//$(source).attr('src', 'http://video-js.zencoder.com/oceans-clip.mp4');
$(source).attr('src', baseURL +  'customerpics/' + localStorage['movieid']);


$("#movie-content").append(obj);
$(obj).append(source);


$('#moviename').append(localStorage['movieheader']);

$('#moviedetail').append(localStorage['moviedetail']);


});

// content size ===========================================================================================================

function getRealContentHeight() {
  var header = $.mobile.activePage.find("div[data-role='header']:visible");
  var footer = $.mobile.activePage.find("div[data-role='footer']:visible");
  var content = $.mobile.activePage.find("div[data-role='content']:visible:visible");
  var viewport_height = $(window).height();

  var content_height = viewport_height - header.outerHeight() - footer.outerHeight();
  if((content.outerHeight() - header.outerHeight() - footer.outerHeight()) <= viewport_height) {
    content_height -= (content.outerHeight() - content.height());
  }
  return content_height;
}

// qr code ===========================================================================================================
function getqrcode(id, userstring) {

  var  id4qr = global_preinstalled_custID;

  userstring = baseURL + '/?id=' + id4qr;

  $.getJSON(serviceURL + 'getqrcode.php?id=' + id4qr + '&userstring=' + userstring, function(data) {


  });
}

// tracker schreiben =======================================================================================================
function writetracker(userid) {

  var serviceURL_tracker = serviceURL + 'posttracker.php';


  $.post(serviceURL_tracker,
  {
    nr: userid

  },

  function (data) {

      // 
      
    });

}



// store JSON data ========================================================================================================
function storeJSONData(data, name){

    var dataToStore = JSON.stringify(data);
    
    localStorage.setItem(name, dataToStore);

}

// retrieve JSON data ========================================================================================================
function retrieveJSONData(name){

   var localData = JSON.parse(localStorage.getItem(name));

   return localData;

}

// json-file item lesen ===================================================================================================
function getJSONObject(JSONObj, itemtyp)
{
  var singleObject;
  var singleStr;

  $.each( JSONObj.items, function(i, obj) {

    if (obj.modulclass === itemtyp){

      singleObject = obj;

      singleStr = singleObject.modulname; // was soll geliefert werden

      console.log (singleStr);

    }


  });

  return singleStr;

}


// eventtester ===========================================================================================================
/*
$("#customerDetailPage").on(
   "pagebeforecreate pagebeforeshow pageinit pageshow pagebeforehide", // etc..
   function(event) {
      alert(event.type);
   }
);
*/
