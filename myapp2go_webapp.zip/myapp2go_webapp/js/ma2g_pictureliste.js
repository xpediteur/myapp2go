// var serviceURL = "http://system3-consulting.de/myapp2go/services/";



/*$('#customerDetailPage').bind('pageinit', function(event) {
	getcouponListe(project_vars.custID, 'coupon');
	
});*/


function getpictures(id, typ , color , bgcolor) {

	
	$.mobile.loading('show');

	$.getJSON(serviceURL + 'getpictures.php?id=' + id, function(data) {

		// Zaehlen der gelieferten Daten Elemeneten
		//countcouponItems = countProperties(data.items);
		//console.log(countcouponItems);

		$('#newsItemListLi li').remove();


		picture = data.items;
		//console.log(data);
		
		
		$.each(picture, function(index, pictureItem) {
			
				/*$('#pictureItemListLi').append(

					'<h4 style="color:#843202;">' + pictureItem.ItemHeading  + ' - ' + pictureItem.Date4Item +   '</h4>' +
					'<p style="color:#843202;">' +  pictureItem.ItemDetails  + '</p>' + '<hr>' );
		*/

		$('#newsItemListLi').append('<li data-icon="delete" style="background:' + bgcolor + ';"><a href="#" class="PictureListInternal" data-identifier="' + pictureItem.ID + '">' +
			
			'<img src="customerpics/' + pictureItem.picname + '" style="width:80px;height:80px;margin-left:3px;margin-top:3px;"/>' +

			'<h5 style="color:' + color + ' ;">' + pictureItem.picname + '</h5>' +

			'<p style="color:' + color + ' ;">' +  pictureItem.date4pic + '</p>' +

			'<span class="ui-li-count" style="color:' + color + ' ;">' + 'Bild' + '</span>' +

			'</a></li>');

		
				//$('#debugInfo').append('debug -> user.Nr # ' + userItem.Nr + ' #<br> ');
				// $('#debugInfo').append('debug -> user.couponItem # ' + couponItem.couponItem + ' #<br> ');


			});

		

		$('#newsItemListLi').listview('refresh');

		

		$.mobile.loading('hide');


		
	});
}



// Anzahl objekte in json-file
function countProperties(obj) {
	var prop;
	var propCount = 0;

	for (prop in obj) {
		propCount++;
	}
	return propCount;
}
