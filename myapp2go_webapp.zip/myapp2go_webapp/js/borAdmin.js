// Initialisierungen ============================================================================================================
// ==============================================================================================================================

var serviceURL  = "http://www.m.myapp2go.de/services/";

var baseURL     = "http://www.m.myapp2go.de/";

var redirecturl = baseURL + 'ma2gAdmin.html'; // !!!!! url - wird fix gesetzt !!!!!

var global_appmodus = false;


project_vars = {};


var flip_html = ' <label for="myflip" id="flip-1-label" class="ui-slider">Bilder physikalisch löschen?</label>'
+' <select name="flip-1" id="myflip" data-role="slider" class="ui-slider-switch" data-mini="true">'
+' <option value="off">Off</option>'
+' <option value="on">On</option>'
+' </select> <br><br>';

var upload_html= '<div data-role="fieldcontain">' +
'<label for="nr">Bilder Upload  </label>' +
'<input id="file_upload" type="file" name="file_upload" data-mini="true"/></div><br>';


// check ob angemeldet

/*
ma2gAdmin_cust_reg
ma2gAdminPage_new

*/

$('[id^="ma2g"]').live('pageshow', function(event) {

//$('#ma2gAdminPage').live('pageshow', function(event) {

  var current = localStorage["userID"];

  if(typeof current == "undefined" || current == '') {

    alert ('Sie sind nicht angemeldet !');

    window.location.href = baseURL + 'Login.html';

  }

});

// Logout variablen leeren ======================================================================================================
$('#AdminLogoutPage').live('pageshow', function(event) {


/*  localStorage["userID"] = '';
  localStorage["custID"] = '';
  */
  ClearLocalStorage();


});


// custID setzten - ooder pagebeforecreate ==========================================================================================
$('#ma2gAdminPage_new').live('pageshow', function(event) {


  // cL editor initialisieren
  $("#detail").cleditor();

  // set userID bei neuem eintrag
  $('#userid').val(localStorage['custID']);


  // set userid + username
  $('#user_data').html('<h5> angemeldete UserID: ' + localStorage['custID'] + ' - ' + localStorage['userID'] + '</h5>');

  call_getNextNum();


});



// !!! ADMIN Seite userID (Name) setzten - ooder pagebeforecreate ===========================================================================
$('#ma2gAdminPage').live('pageshow', function(event) {

  // set userid + username
  $('#user_data').html('<h4> angemeldete UserID: ' + localStorage['custID'] + ' - ' + localStorage['userID'] + '</h4>');

  
  // text dy. schreiben

  $('#dynamic_content').load('templates/myapp2go_infotext.html').trigger("create");

  // $('#dynamic_content').html('<p><b> myapp2go</b> <br><br> Neuigkeiten, Events, Termine, Unternehmsprofil usw. direkt auf dem mobilen Bildschirm Ihrer Kunden. Inhalte einfach und individuell ueber Internetzugang pflegbar. Geringe Kosten, keine laufenden Investionen ihrerseits.Guestige Pauschale deckt die app komplett ab. Ihre Kunden sind mobil, werden sie es auch. Sofort praesent auf dem wichtigsten Phones Ihrer Kunden. Mit einem Klick kommunizieren .Nur Ihr Firmenlogo oder Grafik wird benoetigt. </p>');

  document.title = localStorage['userID'] + ' Admin';

  console.log('angemeldeter USER: ' + localStorage['userID']);

  // dynamic content setzten upload bild
  $('#flipForm').html(upload_html).trigger('create');
  $('#flipForm').hide();


  getmodulListeListview(localStorage['custID']);

  // initialisieren uploadify 
  uploadPic(localStorage['custID'], 0);


   // wenn adminrechte !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
   if (localStorage['isroot'] == 1) {

    var li_userlist_html = '<li data-role="list-divider">Adminbereich</li>' +
    '<li><a href="#" id="li_userlist">Kundenliste</a></li>' +
    '<li><a href="#" id="li_modullist">Modulliste</a></li>' +
    '<li><a href="#" id="li_stat">Gesamt-Statistik</a></li>'+ 
      '<li><a href="#" id="li_delphy">Bilder phy. löschen</a></li>';

    $('#user_data').css('color','red');

    $('#admin_cats').append(li_userlist_html);
    //$('#admin_cats').trigger('create');
    $('#admin_cats').listview('refresh');


  };



});


// Registrierung-Update customer Daten holen -- oder pageinit oder pagebeforecreate =============================================================

$('#ma2gAdmin_cust_reg').live('pageshow', function(event) {


 if (typeof localStorage['custID']  != "undefined" && localStorage['custID']  != null) {


  // set userid + username
  $('#user_data').html('<h4> angemeldete UserID: ' + localStorage['custID'] + ' - ' + localStorage['userID'] + '</h4>');



  // user dürfen nicht speichern nur update
  if (localStorage['isroot'] == 0) {

    $("#submit").parent().hide();

    // readonly setzten 
    $('#userid').attr('readonly','readonly');
    $("#textarea2").attr('readonly','readonly');
    $("#textarea3").attr('readonly','readonly');
    $("#toppic").attr('readonly','readonly');
/*
    $("#passwort").css({"background-color": "#578DBC"});
    $("#passwort2").css({"background-color": "#578DBC"});

    */
  }

  $.mobile.loading('show');
  
    // Kundendaten laden
    $.getJSON(serviceURL + 'getcustomer.php?id=' + localStorage['custID']  , displayCustomer);

  }
  
  // initialisieren uploadify 
  // uploadPic(localStorage['custID'], 0);

});


// passwort ändern Seite ==========================================================================================
$('#ma2gAdmin_pw_chg').live('pageshow', function(event) {


  // set userid + username
  $('#user_data').html('<h4> angemeldete UserID: ' + localStorage['custID'] + ' - ' + localStorage['userID'] + '</h4>');



});



  $('#myflip').on( "change", function(event, ui) { // change event will fire on every selection change


    var myswitch = $(this);
    var show     = myswitch[0].selectedIndex == 1 ? true:false;

    alert (' in change');

   localStorage['toggle_delete_pic'] = $(this); // this.value
   
   console.log(localStorage['toggle_delete_pic']);

   if(show) {


     $('#toggle_delete').popup( "open" );

   }

 });


  $("input[type='radio']").bind( "change", function(event, ui) {


   $('#heading').val('');


   if ( $(this).val()  === 'Coupon' ) {

      // $('#heading').attr("placeholder", "Gutscheinr. wird hier automatsich vergeben!");
      
      var couponNr = randomString(6);

      $('#heading').val('Gutscheinnummer: ' + couponNr);

    }
  });


// aufruf autonum holen ======================================================================================================

function call_getNextNum(){

 $.getJSON(serviceURL + 'getautonum.php', getNextNum);

  // set userID bei neuem eintrag
  $('#userid').val(localStorage['custID']);

 return false;

} 
  

// autonum holen =============================================================================================================
function getNextNum(data) {


  var next_append_num = data.items[0].nu_wert;

  // set neue append_id in form hidden field
  $('#append_id').val(next_append_num);



  // merken in localstorage
  localStorage['next_append_num'] = next_append_num;

  console.log( 'next_append_num an uploadify: ' + localStorage['next_append_num']);

  // initialisieren uploadify fuer docs upload
  uploadPic( localStorage['custID'] , localStorage['next_append_num']);
  
  // set autonum bei neuem eintrag
  $('#nr').val(localStorage['next_append_num']);

  $('#nr').attr('readonly','readonly');

  
  setNextNum(localStorage['next_append_num']);

}


// autonum setzen =============================================================================================================
function setNextNum(anr) {

 var serviceURL_autonum = serviceURL + 'setautonum.php';

 var x = parseInt(anr, 10);

 y = x + 1;


 $.ajax({
  type: "POST",
  url: serviceURL_autonum,
  cache: false,
  data: {id : y},
  success: onSuccess_autonum,
  error: onError_autonum
});

}

function onSuccess_autonum(data, status)
{
  data = $.trim(data);

  $("#notification").text(data);

}

function onError_autonum(data, status)
{
  $("#notification1").text("Fehler!");
}



// customeranzeigen =======================================================================================================
function displayCustomer(data){

  var customerItem = data.item;
/*
   $('#kid' ).val(customerItem.ID);
   $('#kid').attr('readonly','readonly');
   */
   $('#nr' ).val(customerItem.ID);
   $('#userid' ).val(customerItem.UserID);

   $('#passwort' ).val(customerItem.Passwort);
   $('#passwort2' ).val(customerItem.Passwort);


  //$('#name1' ).val(customerItem.Name1);

  
  $('#name1').val(htmlDecode(customerItem.Name1));
  $('#name2' ).val(htmlDecode(customerItem.Name2));
  $('#zusatz' ).val(htmlDecode(customerItem.NameZusatz));
  $('#plz' ).val(htmlDecode(customerItem.PLZ));
  $('#ort' ).val(htmlDecode(customerItem.Ort));
  $('#strasse' ).val(htmlDecode(customerItem.Strasse));
  $('#email' ).val(htmlDecode(customerItem.Email));
  $('#phone' ).val(htmlDecode(customerItem.Phone));
  $('#mobile' ).val(htmlDecode(customerItem.Mobile));

  $('#textarea').val(customerItem.InfoText);
  
  $('#textarea1').val(customerItem.Impressum);

  $('#textarea2').val(htmlDecode(customerItem.facebookstr));
  $('#textarea3').val(htmlDecode(customerItem.googlemapsstr));

  $('#toppic').val(htmlDecode(customerItem.Picture));
  $('#curl').val(htmlDecode(customerItem.URL));


  //$(":input").attr("disabled",true); //Disable all input fields

   // $("#passwort").attr("disabled",true); //Disable all input fields
   // $("#passwort2").attr("disabled",true); //Disable all input fields
   // $("#userid").attr("disabled",true); //Disable all input fields

   $.mobile.loading('hide');

 }


// news aufbauen ==========================================================================================================

$("#li_news").live("click", function(){


 $(".ui-listview-filter").remove();

 $('#newsItemListLi').listview('option', 'filter', true);
 $('#newsItemListLi').listview('refresh');
 $('#newsItemListLi').trigger("listviewcreate");

 $('#dynamic_content').empty();

 clear_li();
 set_visibility();

 $('#dynamic_content').html('<h4>Klicken Sie auf einen Eintrag um diesen zu Löschen</h4>');

 getnewsListe(localStorage['custID'], 'News');

 $('html, body').animate({scrollTop:$('#dynamic_content').position().top }, 'slow');

 $('#divider').text('news');

});

// events aufbauen ==========================================================================================================
$("#li_events").live("click", function(){


  $(".ui-listview-filter").remove();

  $('#newsItemListLi').listview('option', 'filter', true);
  $('#newsItemListLi').listview('refresh');
  $('#newsItemListLi').trigger("listviewcreate");

  $('#dynamic_content').empty();

  clear_li();
  set_visibility();

  $('#dynamic_content').html('<h4>Klicken Sie auf einen Eintrag um diesen zu Löschen</h4>');

  geteventListe(localStorage['custID'], 'Event');

  $('html, body').animate({scrollTop:$('#dynamic_content').position().top}, 'slow');

  $('#divider').text('events');
});

// coupon aufbauen ==========================================================================================================
$("#li_coupon").live("click", function(){

  $(".ui-listview-filter").remove();

  $('#newsItemListLi').listview('option', 'filter', true);
  $('#newsItemListLi').listview('refresh');
  $('#newsItemListLi').trigger("listviewcreate");

  $('#dynamic_content').empty();

  clear_li();
  set_visibility();

  $('#dynamic_content').html('<h4>Klicken Sie auf einen Eintrag um diesen zu Löschen</h4>');

  getcouponListe(localStorage['custID'], 'Coupon');

  $('html, body').animate({scrollTop:$('#dynamic_content').position().top}, 'slow');

  $('#divider').text('coupons');

});

// documnete aufbauen ==========================================================================================================
$("#li_docs").live("click", function(){

 $(".ui-listview-filter").remove();

 $('#documentItemListLi').listview('option', 'filter', true);
 $('#documentItemListLi').listview('refresh');
 $('#documentItemListLi').trigger("listviewcreate");
 
 $('#dynamic_content').empty();

 clear_li();
 set_visibility();

 $('#dynamic_content').html('<h4>Klicken Sie auf einen Eintrag um diesen zu Löschen</h4>');

 getdocumentListe(localStorage['custID'], 'Document');

 $('html, body').animate({scrollTop:$('#dynamic_content').position().top}, 'slow');

 $('#divider').text('Documente');


});


// user aufbauen ======================================================================================================
$("#li_userlist").live("click", function(){

 $(".ui-listview-filter").remove();

 $('#newsItemListLi').listview('option', 'filter', true);
 $('#newsItemListLi').listview('refresh');
 $('#newsItemListLi').trigger("listviewcreate");

 
 $('#dynamic_content').empty();

 clear_li();
 set_visibility();

 $('#dynamic_content').html('<h4>Kundenliste - Klicken Sie auf den Eintrag zum bearbeiten oder übernehmen</h4>');

 getuserListe(localStorage['custID'], 'User');

 $('html, body').animate({scrollTop:$('#dynamic_content').position().top}, 'slow');

 $('#divider').text('User');
});

// Bilder aufbauen ======================================================================================================
$("#li_gallery").live("click", function(){


 $(".ui-listview-filter").remove();

 $('#newsItemListLi').listview('option', 'filter', true);
 $('#newsItemListLi').listview('refresh');
 $('#newsItemListLi').trigger("listviewcreate");

 $('#dynamic_content').empty();

 clear_li();


 $('#dynamic_content').html('<h4>Klicken Sie auf einen Eintrag um diesen zu Löschen oder Bilder hochzuladen</h4>');

 $('#flipForm').show();


 getpictures(localStorage['custID'], 'User');

 $('html, body').animate({scrollTop:$('#dynamic_content').position().top}, 'slow');

 $('#divider').text('Bilder');
});

// stat aufbauen ======================================================================================================
$("#li_stat").live("click", function(){

  $(".ui-listview-filter").remove();

  $('#dynamic_content').empty();

  clear_li();
  set_visibility();

  $('#dynamic_content').html('<h4>Gesamt-Statistik der Aufrufe der apps</h4>');

  getstatistik();

  $('html, body').animate({scrollTop:$('#dynamic_content').position().top}, 'slow');

  $('#divider').text('Statistik');
});

// qr aufbauen ======================================================================================================
$("#li_qrcode").live("click", function(){

  $(".ui-listview-filter").remove();

  $('#dynamic_content').empty();

  clear_li();
  set_visibility();

  $('#dynamic_content').html('<h4>QR Code für ihre Kunden</h4>');

  getqrcode();

  var picname = localStorage['custID'] + '_' + 'qrfile.png';

  $('#dynamic_content').append('<p><img id="qrcodepic"></p>');
  $('#dynamic_content').trigger('create');

  $('#qrcodepic').attr('src', 'customerpics/' + picname);
  $('#dynamic_content').trigger('create');

  $('html, body').animate({scrollTop:$('#dynamic_content').position().top}, 'slow');

  $('#divider').text('QR Code');
});

// module aufbauen ======================================================================================================
$("#li_modullist").live("click", function(){

  $(".ui-listview-filter").remove();

  $('#newsItemListLi').listview('option', 'filter', true);
  $('#newsItemListLi').listview('refresh');
  $('#newsItemListLi').trigger("listviewcreate");

  $('#dynamic_content').empty();

  clear_li();
  set_visibility();

  $('#dynamic_content').html('<h4>Modulliste - Reihenfolge der Kundenmodule </h4>');

  getmodulListe(localStorage['custID'], 'User');

  $('html, body').animate({scrollTop:$('#dynamic_content').position().top}, 'slow');

  $('#divider').text('Module');
});

// preview aufbauen ======================================================================================================
$("#li_preview").live("click", function(){

  window.location.href = baseURL + 'iframe_preview.html?id=' + localStorage['custID'];

  $('#divider').text('app Preview');
});


// stat cust aufbauen ======================================================================================================
$("#li_stat_cust").live("click", function(){

 $(".ui-listview-filter").remove();

 $('#dynamic_content').empty();

 clear_li();
 set_visibility();

 $('#dynamic_content').html('<h4>Statistik der Aufrufe der apps</h4>');

 getstatistik_customer(localStorage['custID']);

 $('html, body').animate({scrollTop:$('#dynamic_content').position().top}, 'slow');

 $('#divider').text('Statistik');
});

// movie aufbauen ======================================================================================================
$("#li_movie").live("click", function(){


 $('#dynamic_content').empty();

 clear_li();
 set_visibility();

 $('#dynamic_content').html('<h4>Klicken Sie auf einen Eintrag um diesen zu Löschen</h4>');

 getmovieListe(localStorage['custID'], '');

 $('html, body').animate({scrollTop:$('#dynamic_content').position().top}, 'slow');

 $('#divider').text('Filme');
});


// blog aufbauen ======================================================================================================
$("#li_blog").live("click", function(){


 $('#dynamic_content').empty();

 clear_li();
 set_visibility();

 $('#dynamic_content').html('<h4>Klicken Sie auf einen Eintrag um diesen zu Löschen</h4>');

 getblogListe(localStorage['custID'], '');

 $('html, body').animate({scrollTop:$('#dynamic_content').position().top}, 'slow');

 $('#divider').text('Blog / Gästebuch');
});

//löschen bilder aufbauen ======================================================================================================
$("#li_delphy").live("click", function(){

  $(".ui-listview-filter").remove();

  $('#dynamic_content').empty();

  clear_li();
  set_visibility();

  $('#dynamic_content').html('<h4>Löschung der Bilder</h4>');

  callDeletePicture(localStorage['custID']);

  $('html, body').animate({scrollTop:$('#dynamic_content').position().top}, 'slow');

  $('#divider').text('Statistik');
});

// qr aufbauen ======================================================================================================



/*  $("#email").bind("change", function(e){
  $.getJSON("http://yourwebsite.com/lokup.php?email=" + $("#email").val(),
        function(data){
          $.each(data, function(i,item){
            if (item.field == "first_name") {
              $("#first_name").val(item.value);
            } else if (item.field == "last_name") {
              $("#last_name").val(item.value);
            }
          });
        });
});*/


/*

$('#documentItemListLi').on('click', 'a' , function (event) {


alert ( 'in doclist' );

});



$('#newsItemListLi').on('click', 'a' , function (event) {

alert ( 'in newslist' );

var tbool_item = $(this).hasClass('ItemListInternal ui-link-inherit');

if (tbool_item) {

alert (' news class');

};

});

*/



// click auf listeneintrag auswerten -> delete =============================================================================

$("div:jqmData(role='page') div:jqmData(role='content') ul:jqmData(role='listview') li a").live('click', function(event, ui) {


  console.log('in delete click');

  var tbool_item = false;

  var tbool_pic  = false;

  var tbool_doc  = false;

  var tbool_user = false;

  var tbool_movie = false;

  var tbool_blog = false;

  
  tbool_item = $(this).hasClass('ItemListInternal ui-link-inherit');

  tbool_pic  = $(this).hasClass('PictureListInternal ui-link-inherit');

  tbool_doc  = $(this).hasClass('DocumentListInternal ui-link-inherit');

  tbool_user = $(this).hasClass('UserListInternal ui-link-inherit');

  tbool_movie = $(this).hasClass('MovieListInternal ui-link-inherit');

  bool_blog = $(this).hasClass('BlogListInternal ui-link-inherit');

  

  var delObj = $(this);

   // data-identifier holen = ID und merken bei news event coupon user pic
   var aktItemID = $(this).jqmData('identifier');

   // data-identifier holen = ID und merken bei documents / blog 
   var aktItemID_document = $(this).jqmData('identifierid');


      // wenn class = ItemListInternal
      if (tbool_item) {


        $('#delete_dialog').popup( "open" );

        $('.delete_ja').live('click',function() {

         delObj.closest("li").remove();

         $('#newsItemListLi').listview('refresh');

         updateItem(aktItemID);


       });


      }

       // wenn class = pic
       if (tbool_pic) {


        $('#delete_dialog').popup( "open" );

        $('.delete_ja').live('click',function() {

         delObj.closest("li").remove();

         $('#newsItemListLi').listview('refresh');

         updatePicture(aktItemID);

         //deletePhyDocument(aktItemID);


       });


      }

       // wenn class = doc
       if (tbool_doc) {


        $('#delete_dialog').popup( "open" );

        $('.delete_ja').live('click',function() {

         delObj.closest("li").remove();

         $('#documentItemListLi').listview('refresh');

         updateDocument(aktItemID_document);



       });


      }

      // wenn class = movie
      if (tbool_movie) {


        $('#delete_dialog').popup( "open" );

        $('.delete_ja').live('click',function() {

         delObj.closest("li").remove();

         $('#movieItemListLi').listview('refresh');

         updateDocument(aktItemID_document);


       });


      }


      // wenn class = blog
      if (tbool_blog) {


        $('#delete_dialog').popup( "open" );

        $('.delete_ja').live('click',function() {

         delObj.closest("li").remove();

         $('#blogItemListLi').listview('refresh');

         updateBlog(aktItemID_document);


       });


      }

    // wenn class = user - Wechsel zum Kunden
    if (tbool_user) {


      localStorage['custID'] = aktItemID; // mit ID wechseln

      window.location.href = baseURL + 'ma2gAdmin_cust_reg.html';

      
    }


  });

// uploadfy =======================================================================================================================

function uploadPic(cid, aid) {

 console.log(' in uploadpic cust:' + localStorage['custID']);
 console.log(' in uploadpic item:' + localStorage['next_append_num']);

 $('#file_upload').uploadifive({
  'uploadScript' : serviceURL + 'uploadify.php',
  'cancelImg': '/m.myapp2go/pics/uploadify-cancel.png',
  'width'        : 110,
  'method'   : 'post',
  'buttonText'    : 'Auswahl',
  'formData' : { 'custid' :  cid, 'append_id' : aid }
    // ...
  });


}

//* eingaben cust checken ===================================================================================================

$( "#passwort2" ).blur(function() {

  //remove all the class add the messagebox classes and start fading
  $("#msgbox").removeClass().addClass('messagebox').html('<img align="absmiddle" src="images/ajax-loader.png" /> <p style="color: red;"> Checking passwort ... ').fadeIn("slow");


  var pass1=(document.new_cust.passwort.value);
  var pass2=(document.new_cust.passwort2.value);

  if  (pass1 != pass2)


  {

        $("#msgbox").fadeTo(200,0.1,function() //start fading the messagebox
        {
          //add message and change the class of the box and start fading
          $(this).html(' <p style="color: red;">  passwort 1 & 2 ungleich ').addClass('messageboxerror').fadeTo(900,1);
        });
        
        //document.formregister.passwort_2.focus(); 
      }
      else
      {
        $("#msgbox").fadeTo(200,0.1,function()  //start fading the messagebox
        { 
          //add message and change the class of the box and start fading
          $(this).html(' <p style="color: green;">  passwort ist OK').addClass('messageboxok').fadeTo(900,1); 
        });
        

      }

  // alert( "Handler for .blur() called." );
});




// $ajax - insert update der Daten =======================================================================================
function onSuccess(data, status)
{
  data = $.trim(data);

  $("#notification").text(data);
  
  
}

function onError(data, status)
{
  $("#notification1").text("DB-Fehler!");
}


//  $ajax - item (news event coupon  ) neu ==============================================================================

/*
 $(document).ready(function() {
  $("#ma2gAdmin_item_insert #submit").click(function(){

    var serviceURL_insert = serviceURL + 'ma2gAdmin_item_insert.php';

    var formData = $("#ma2gAdmin_item_insert").serialize();

    console.log(formData);

    $.ajax({
      type: "POST",
      url: serviceURL_insert,
      cache: false,
      data: formData,
      success: onSuccess,
      error: onError
    });

    return false;
  });
});
*/


//  $ajax - item neu =================================================================================================
function call_ajax_item_insert()
{

  var serviceURL_insert = serviceURL + 'ma2gAdmin_item_insert.php';

  var formData = $("#ma2gAdmin_item_insert").serialize();

    // console.log(formData);

    $.ajax({
      type: "POST",
      url: serviceURL_insert,
      cache: false,
      data: formData,
      success: onSuccess,
      error: onError
    });

    return false;

  }

//  $ajax - customer neu =================================================================================================
$(document).ready(function() {
  $("#ma2gAdmin_cust_insert #submit").click(function(){

    var register_pass = $('#passwort').val();

    console.log('passwort eingegeben: ' + register_pass);

    var register_enc = register_pass.rot13();

    console.log('passwort cryptiert: ' + register_enc);

    var register_cipherPass = toHex( register_enc );

    console.log('passwort hex      : ' + register_cipherPass);

    // input hidden zu form 
    $('<input>').attr({
      type: 'hidden',
      value: register_cipherPass,
      name: 'p'
    }).appendTo('#ma2gAdmin_cust_insert');


    // Make sure the plaintext password doesn't get sent.

    $('#passwort').val('');


    var serviceURL_insert = serviceURL + 'ma2gAdmin_cust_insert.php';

    var formData = $("#ma2gAdmin_cust_insert").serialize();

    console.log(formData);

    $.ajax({
      contentType: 'application/x-www-form-urlencoded; charset=UTF-8',
      type: "POST",
      url: serviceURL_insert,
      cache: false,
      data: formData,
      success: onSuccess,
      error: onError
    });

    return false;
  });
});

//  $ajax - customer update =================================================================================================
$(document).ready(function() {
  $("#ma2gAdmin_cust_insert #update").click(function(){


    var serviceURL_email = serviceURL + 'ma2gAdmin_cust_update.php';

    var formData = $("#ma2gAdmin_cust_insert").serialize();


    $.ajax({
      contentType: 'application/x-www-form-urlencoded; charset=UTF-8',
      type: "POST",
      url: serviceURL_email,
      cache: false,
      data: formData,
      success: onSuccess,
      error: onError
    });

    return false;
  });
});


//  $ajax - Passwort update =================================================================================================
function call_ajax_pw_change()
{

 var register_pass = $('#password').val();

 console.log('passwort eingegeben: ' + register_pass);

 var register_enc = register_pass.rot13();

 console.log('passwort cryptiert: ' + register_enc);

 var register_cipherPass = toHex( register_enc );

 console.log('passwort hex      : ' + register_cipherPass);

    // input hidden zu form 
    $('<input>').attr({
      type: 'hidden',
      value: register_cipherPass,
      name: 'p'
    }).appendTo('#ma2gAdmin_pw_change');


     // input hidden zu form hier custID
     $('<input>').attr({
      type: 'hidden',
      value: localStorage['custID'],
      name: 'cid'
    }).appendTo('#ma2gAdmin_pw_change');


    // Make sure the plaintext password doesn't get sent.

    $('#password').val('');
    $('#password2').val('');

    var serviceURL_pwupdate = serviceURL + 'ma2gAdmin_pw_update.php';

    var formData = $("#ma2gAdmin_pw_change").serialize();


    $.ajax({
      contentType: 'application/x-www-form-urlencoded; charset=UTF-8',
      type: "POST",
      url: serviceURL_pwupdate,
      cache: false,
      data: formData,
      success: onSuccess,
      error: onError
    });

    return false;

  }



// check user $ajax für LOGIN ==================================================================================================
$(document).ready(function() {
  $("#ma2g_user_check #submit").click(function(){


    var input_pass = $('#pass').val();

    var enc = input_pass.rot13();

    var cipherPass = toHex( enc );
    

    // input hidden zu form 
    $('<input>').attr({
      type: 'hidden',
      value: cipherPass,
      name: 'p'
    }).appendTo('#ma2g_user_check');


    // Make sure the plaintext password doesn't get sent.
    
    $('#pass').val('');


    var serviceURL_insert = serviceURL + 'ma2g_user_check.php';

    var formData = $("#ma2g_user_check").serialize();

    $.ajax({
      type: "POST",
      url: serviceURL_insert,
      cache: false,
      data: formData,
      success: onSuccess_usercheck,
      error: onError_usercheck
    });

    return false;
  });

});

function onSuccess_usercheck(data, status)
{
  data = $.trim(data);
  
  console.log(data);

  var split = data.split('-');

  var msg     = split[0];
  var cust_ID = split[1];
  var user_ID = split[2];
  var isroot  = split[3];


  console.log(msg);
  console.log(cust_ID);
  console.log(user_ID);
  console.log(isroot);

  if (msg == 'OK') {

      // globale CustID zuweisen
      project_vars.custID = cust_ID;
      localStorage['custID']  = project_vars.custID;

     // globale UserID zuweisen
     project_vars.userID = user_ID ;
     localStorage['userID']  = project_vars.userID;

      // globale isrrot zuweisen
      project_vars.isroot = isroot ;
      localStorage['isroot']  = project_vars.isroot;


      window.location.href = redirecturl;


    } else{

      $("#notification").text(data);

    };


  }

  function onError_usercheck(data, status)
  {
    $("#notification").text("DB-Fehler!");
  }


// item update isdelete setzen ================================================================================================
function updateItem(tnr) {

 var serviceURL_updateItem = serviceURL + 'ma2g_update_item.php';

 $.ajax({
  type: "POST",
  url: serviceURL_updateItem,
  cache: false,
  data: {id : tnr},
  success: onSuccess_updateItem,
  error: onError_updateItem
});

}

function onSuccess_updateItem(data, status)
{
  data = $.trim(data);
  $("#notification1").text(data);

}

function onError_updateItem(data, status)
{
  $("#notification1").text("Fehler!");
}

// custompicture update isdelete setzen ================================================================================================
function updatePicture(id) {

 var serviceURL_updatepicture = serviceURL + 'ma2g_update_picture.php';

 $.ajax({
  type: "POST",
  url: serviceURL_updatepicture,
  cache: false,
  data: {id : id},
  success: onSuccess_updatepicture,
  error: onError_updatepicture
});

}

function onSuccess_updatepicture(data, status)
{
  data = $.trim(data);
  $("#notification1").text(data);

}

function onError_updatepicture(data, status)
{
  $("#notification1").text("Fehler!");
}

// Document + custompicture update isdelete setzen ================================================================================================
function updateDocument(id) {

 var serviceURL_updatedocument = serviceURL + 'ma2g_update_document.php';

 $.ajax({
  type: "POST",
  url: serviceURL_updatedocument,
  cache: false,
  data: {id : id},
  success: onSuccess_updatedocument,
  error: onError_updatedocument
});

}

function onSuccess_updatedocument(data, status)
{
  data = $.trim(data);
  $("#notification1").text(data);

}

function onError_updatedocument(data, status)
{
  $("#notification1").text("Fehler!");
}

// Document Bilder physikalisch löschen ===================================================================================
function deletePhyDocument(id) {

 var serviceURL_deletedocument = serviceURL + 'ma2g_delete_document_physical.php';

 $.ajax({
  type: "POST",
  url: serviceURL_deletedocument,
  cache: false,
  data: {id : id},
  success: onSuccess_deletedocument,
  error: onError_deletedocument
});

}

function onSuccess_deletedocument(data, status)
{
  data = $.trim(data);
  $("#notification1").text(data);

}

function onError_deletedocument(data, status)
{
  $("#notification1").text("Fehler!");
}



// BLOG Update update isdelete setzen ================================================================================================
function updateBlog(id) {

 var serviceURL_updateblog = serviceURL + 'ma2g_update_blog.php';

 $.ajax({
  type: "POST",
  url: serviceURL_updateblog,
  cache: false,
  data: {id : id},
  success: onSuccess_updateblog,
  error: onError_updateblog
});

}

function onSuccess_updateblog(data, status)
{
  data = $.trim(data);
  $("#notification1").text(data);

}

function onError_updateblog(data, status)
{
  $("#notification1").text("Fehler!");
}


//clear buttons ======================================================================================================

// neuer eintrag item
$("#ma2gAdmin_item_insert #clear").click(function(){

  $('#ma2gAdmin_item_insert').trigger("reset");

  // call_getNextNum();

 // $('input[type="text"]').val('');

 // $('#notification').text('');

});

// werte löschen in item new - clear
$("#ma2gAdmin_cust_insert #clear").click(function(){

  $('#ma2gAdmin_cust_insert').trigger("reset");

 // $('input[type="text"]').val('');

 // $('#notification').text('');
 
});

// werte löschen passwort ändern
$("#ma2gAdmin_pw_change #clear").click(function(){

  $('#ma2gAdmin_pw_change').trigger("reset");

 // $('input[type="text"]').val('');

 // $('#notification').text('');
 
});

//============================================================================================================================

function getqrcode(id, userstring) {

  var  id4qr = localStorage['custID'];

  userstring = baseURL + '?id=' + id4qr;

  $.getJSON(serviceURL + 'getqrcode.php?id=' + id4qr + '&userstring=' + userstring, function(data) {


  });
}

//============================================================================================================================
function toHex(str) {
  var hex = '';
  for(var i=0;i<str.length;i++) {
    hex += ''+str.charCodeAt(i).toString(16);
  }
  return hex;
}

//============================================================================================================================
String.prototype.rot13 = function(){
  return this.replace(/[a-zA-Z]/g, function(c){
    return String.fromCharCode((c <= "Z" ? 90 : 122) >= (c = c.charCodeAt(0) + 13) ? c : c - 26);
  });
};

//============================================================================================================================
function randomString(len, charSet) {
  charSet = charSet || 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  var randomString = '';
  for (var i = 0; i < len; i++) {
    var randomPoz = Math.floor(Math.random() * charSet.length);
    randomString += charSet.substring(randomPoz,randomPoz+1);
  }
  return randomString;
}

// decode der Sonderzeichen =================================================================================================
function htmlDecode(value) {
  if (value) {
    return $('<div />').html(value).text();
  } else {
    return '';
  }
}

//form sichtbar/nicht sichtbar =============================================================================================
function set_visibility() {

 /*if ($('#flipForm').css('visibility')=='hidden'){
                    $('#flipForm').css('visibility', 'visible');
                } else {
                    $('#flipForm').css('visibility', 'hidden');
                  }*/
                  $('#flipForm').hide();

                }

// LISTVIE clear ============================================================================================================
function clear_li() {

  $('#newsItemListLi li').remove();
  $('#documentItemListLi li').remove();
  $('#movieItemListLi li').remove();
  $('#blogItemListLi li').remove();
}

// localstorage clear =======================================================================================================
function ClearLocalStorage() {

  Object.keys(localStorage)
  .forEach(function(key){

    localStorage.removeItem(key);

  });
}

// popup  ========================================================================================================================
var toast=function(msg){
  $("<div class='ui-loader ui-overlay-shadow ui-body-d ui-corner-all' ><h5>"+msg+"</h5></div>")
  .css({ display: "block",
    opacity: 0.90, 
    position: "fixed",
    padding: "7px",
    color: "grey",
    "text-align": "center",
    width: "270px",
    left: ($(window).width() - 284)/2,
    top: $(window).height()/2 })
  .appendTo( $.mobile.pageContainer ).delay( 3000 )
  .fadeOut( 400, function(){
    $(this).remove();
  });
};


$('#btinfo').on('click', function() {

  toast('myapp2go app center <br> Hilfethemen');

});

