// var serviceURL = "http://system3-consulting.de/myapp2go/services/";



/*$('#customerDetailPage').bind('pageinit', function(event) {
	getcouponListe(project_vars.custID, 'coupon');
	
});*/


function getmodulListe(id, typ , color , bgcolor) {

		
	$.mobile.loading('show');

	$.getJSON(serviceURL + 'getmodules.php?id=' + id, function(data) {

		// Zaehlen der gelieferten Daten Elemeneten
		//countcouponItems = countProperties(data.items);
		//console.log(countcouponItems);

		$('#newsItemListLi li').remove();


		modul = data.items;
		//console.log(data);
		
		
		$.each(modul, function(index, modulItem) {
			
				/*$('#modulItemListLi').append(

					'<h4 style="color:#843202;">' + modulItem.ItemHeading  + ' - ' + modulItem.Date4Item +   '</h4>' +
					'<p style="color:#843202;">' +  modulItem.ItemDetails  + '</p>' + '<hr>' );
		*/

		$('#newsItemListLi').append('<li data-icon="arrow-d" style="background:' + bgcolor + ';"><a href="#" class="modulListInternal" data-identifier="' + modulItem.ID + '">' +
			
			'<h4 style="color:' + color + ' ;">' + modulItem.modulname + ' - (class) ' + modulItem.modulclass  + '</h4>' +

			'<p style="color:' + color + ' ;">' +  'Order : ' + modulItem.modulorder + '</p>' +

			'<p style="color:' + color + ' ;">' +  'Counter : ' + modulItem.modulcounter  +  '  |  Aktiv: ' + modulItem.isDeleted + '</p>' +

			'<span class="ui-li-count" style="color:' + color + ' ;">' + 'modul' + '</span>' +

			'</a></li>');

		
				//$('#debugInfo').append('debug -> modul.Nr # ' + modulItem.Nr + ' #<br> ');
				// $('#debugInfo').append('debug -> user.couponItem # ' + couponItem.couponItem + ' #<br> ');


			});

		

		$('#newsItemListLi').listview('refresh');

		

		$.mobile.loading('hide');


		
	});
}



// Anzahl objekte in json-file
function countProperties(obj) {
	var prop;
	var propCount = 0;

	for (prop in obj) {
		propCount++;
	}
	return propCount;
}
