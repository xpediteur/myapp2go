
$('#ItemDetailPage').on('pagebeforeshow', function(event) {

    // Übergabe der ID aus Liste
	var id = project_vars.idMerker;

	$('#itemheading').empty();
	$('#itemdetail').empty();
	$('#detailpic').find('img').remove();
	
	
	$.mobile.loading('show');

	$.getJSON(serviceURL + 'getitemdetail.php?id='+id, displayDetails);

});

function displayDetails(data) {


	var itemdetail = data.item;

	var htmlheading = itemdetail.ItemHeading.replace(/(\r\n|\n|\r)/gm, "<br />");
	var htmldetail = itemdetail.ItemDetails.replace(/(\r\n|\n|\r)/gm, "<br />");

	htmldetail = htmlDecode(htmldetail);

	
	if (itemdetail.picname) {

		 $('#detailpic').append('<img src="'+ 'customerpics/' + itemdetail.picname + '"  style="width:100px;height:100px;margin-left:15px;margin-top:1px;margin-bottom:3px;"' + ' />');

		// $('#itemPic').attr('src', 'customerpics/' + itemdetail.picname);
	
	} else{

		$('#detailpic').find('img').remove();

	}

	$('#itemheading').append(htmlheading);

	$('#itemtyp').text(itemdetail.ItemTyp);

	$('#itemdate').text('Datum: ' +itemdetail.Date4Item);

	$('#itemdetail').append(htmldetail);
	
	
	
	//email - string für href aufbauen und setzten -> item senden
	var mailrefferer = "mailto:empfäenger@eingeben.de?subject=myapp2go -  " + itemdetail.Date4Item + ' - ' + itemdetail.ItemHeading + "&body=" + ' ' + htmldetail;

	$('#itemsendmail').attr('href', mailrefferer);

	$.mobile.loading('hide');

}
