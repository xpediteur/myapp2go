
function callDeletePicture(id) {


	$.mobile.loading('show');

	$.getJSON(serviceURL + 'ma2g_delete_document_physical.php?id=' + id, function(data) {

		
		var piccount = 0;

		delobj = data.items;
		//console.log(data);
		
		var stat_html = 
 		'<table data-role="table" id="movie-table-custom" data-mode="reflow" class="movie-list table-stroke">'+
 		'<thead>  <tr> <th data-priority="1">gelöscht</th> <th data-priority="2">Dateiname</th>  </tr> </thead>';
		
		$.each(delobj, function(index, delobjItem) {

			stat_html +=

			'<tbody> <tr> <th>Bild</th>  <td>' + delobjItem.picname + '</td> </tr>';

			piccount++;
								
		$.mobile.loading('hide');
		
	});

	

	stat_html += '</tbody> </table> <br>';

	// dynamic content setzten
	 $('#dynamic_content').html('<h4>' + piccount + ' Bilder wurden vom Server gelöscht</h4>');	
	 $('#dynamic_content').append(stat_html).trigger('create');


});

}


// Anzahl objekte in json-file
function countProperties(obj) {
	var prop;
	var propCount = 0;

	for (prop in obj) {
		propCount++;
	}
	return propCount;
}
