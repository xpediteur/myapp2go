

//dynamic

var ListItemColor   = "#000000";
var ListItembgColor = "#F3E1B9";



// var custPicture       = "heigl_top.png";