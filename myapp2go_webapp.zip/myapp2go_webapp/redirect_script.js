var ua = navigator.userAgent.toLowerCase();

if(ua.search(/(iphone|ipod|opera mini|palm|blackberry|android|symbian|series60)/)>-1){
    
  window.location.href = 'http://www.m.myapp2go.de/?id=3';
  
}