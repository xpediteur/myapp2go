-- phpMyAdmin SQL Dump
-- version 2.6.4-pl3
-- http://www.phpmyadmin.net
-- 
-- Host: db483439695.db.1and1.com
-- Erstellungszeit: 21. August 2013 um 15:55
-- Server Version: 5.1.71
-- PHP-Version: 5.3.3-7+squeeze16
-- 
-- Datenbank: `db483439695`
-- 

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `account`
-- 

CREATE TABLE `account` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` varchar(25) NOT NULL,
  `Passwort` varchar(255) NOT NULL,
  `Name1` varchar(255) NOT NULL,
  `Name2` varchar(255) NOT NULL,
  `NameZusatz` varchar(255) NOT NULL,
  `PLZ` varchar(10) NOT NULL,
  `Ort` varchar(255) NOT NULL,
  `Strasse` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Phone` varchar(255) NOT NULL,
  `Mobile` varchar(255) NOT NULL,
  `md5string` varchar(255) NOT NULL,
  `isdeleted` varchar(1) NOT NULL,
  `LogInfo` varchar(255) DEFAULT NULL,
  `InfoText` text,
  `Impressum` text,
  `Picture` varchar(255) NOT NULL,
  `URL` varchar(255) NOT NULL,
  `facebookstr` text NOT NULL,
  `googlemapsstr` text NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UserID` (`UserID`),
  FULLTEXT KEY `InfoText` (`InfoText`)
) ENGINE=MyISAM AUTO_INCREMENT=10005 DEFAULT CHARSET=utf8 AUTO_INCREMENT=10005 ;

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `customercalls`
-- 

CREATE TABLE `customercalls` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `custid` int(11) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `info` varchar(500) NOT NULL,
  `date4call` date NOT NULL,
  `isDeleted` tinyint(1) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=131 DEFAULT CHARSET=utf8 AUTO_INCREMENT=131 ;

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `customerpics`
-- 

CREATE TABLE `customerpics` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `custid` int(11) NOT NULL,
  `picname` varchar(255) NOT NULL,
  `picinfo` varchar(255) NOT NULL,
  `date4pic` date NOT NULL,
  `isDeleted` tinyint(1) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `picname` (`picname`)
) ENGINE=MyISAM AUTO_INCREMENT=92 DEFAULT CHARSET=utf8 AUTO_INCREMENT=92 ;

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `infotable`
-- 

CREATE TABLE `infotable` (
  `ItemId` int(11) NOT NULL AUTO_INCREMENT,
  `UserId` varchar(11) NOT NULL,
  `ItemTyp` varchar(20) NOT NULL,
  `ItemHeading` varchar(100) NOT NULL,
  `ItemDetails` varchar(500) NOT NULL,
  `isDeleted` tinyint(1) DEFAULT '0',
  `Date4Item` date DEFAULT NULL,
  PRIMARY KEY (`ItemId`)
) ENGINE=MyISAM AUTO_INCREMENT=435435629 DEFAULT CHARSET=utf8 AUTO_INCREMENT=435435629 ;



CREATE TABLE `customermodules` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `custid` int(11) NOT NULL,
  `modulcat` varchar(255) NOT NULL,
  `modulname` varchar(255) NOT NULL,
  `modulclass` varchar(255) NOT NULL,
  `date4mod` date NOT NULL,
  `isDeleted` tinyint(1) NOT NULL,
  PRIMARY KEY (`ID`)
 ) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ;
