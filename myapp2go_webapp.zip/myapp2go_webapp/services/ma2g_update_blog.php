<?php
include 'config.php';

if (isset($_POST['id'])){
 
                $reg_id = htmlentities($_POST['id'],ENT_QUOTES,"UTF-8");

} else{

                $reg_id = "";

}

$sql = "update customerblog set isDeleted = 1 where ID=:id;";


try {

                $dbh = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);          

                $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                $stmt = $dbh->prepare($sql);
				
		$stmt->bindParam("id", $reg_id);

                $stmt->execute();

                $dbh = null;

                echo 'update OK'; 

} catch(PDOException $e) {

                echo '{"error":{"text":'. $e->getMessage() . $sql .  '}}'; 

} 
 

?>