<?php header('Access-Control-Allow-Origin: *'); ?>
<?php
include 'config.php';




if (isset($_GET['id'])){

				$get_id = htmlentities($_GET['id'],ENT_QUOTES,"UTF-8");
				
				} else{
				
					$get_id = "0";
			}

function utf8_string_array_encode(&$array){
    $func = function(&$value,&$key){
        if(is_string($value)){
            $value = utf8_encode($value);
        } 
        if(is_string($key)){
            $key = utf8_encode($key);
        }
        if(is_array($value)){
            utf8_string_array_encode($value);
        }
    };
    array_walk($array,$func);
    return $array;
}

//$sqlitem = "SELECT * FROM infotable where ItemId=:id;";


$sqlitem = 'SELECT * '
        . ' FROM infotable i'
        . ' LEFT OUTER JOIN customerpics c ON i.ItemId = c.appendID'
        . ' WHERE i.ItemId=:id ;';
        

try {
	$dbh = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);	
	$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	
	$stmt = $dbh->prepare($sqlitem);

	// $stmt->bindParam("typ", $get_typ);
	$stmt->bindParam("id", $get_id);


	$stmt->execute();

	$counts = $stmt->fetchObject();  
	
	$dbh = null;

	$clean = utf8_string_array_encode($counts);

	echo '{"item":' . json_encode($counts) .'}'; 

/*	
	$logfile = fopen("JQMBOR_logfile.log", "a"); // wird die Logdatei geöffnet
    $logtext = $_SERVER['REMOTE_ADDR'] . " -- " . date("d.m.Y H:i:s"). " - ". "JSON Daten counter: " .json_encode($counts)." -- .\r\n\r\n"; // und die Fehlermeldung (inkl. Datum/Uhrzeit und dem Query)
    fwrite($logfile, $logtext); // in die Logdatei geschrieben
    fclose($logfile);          // und zum Schluss wird die Logdatei wieder geschlossen
  */  

} catch(PDOException $e) {

	echo '{"error":{"text":'. $e->getMessage() .'}}'; 
}

?>