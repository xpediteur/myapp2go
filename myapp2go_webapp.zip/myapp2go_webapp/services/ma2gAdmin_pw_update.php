<?php header ('Content-type: text/html; charset=utf-8'); ?>
<?php
include 'config.php';


$md5_reg = '';
$isdeleted = 0;




if (isset($_POST['cid'])){

	$nr = ($_POST['cid']);

} else{

	$nr = 0;
}

if (isset($_POST['password'])){

	$passwort = htmlentities($_POST['password'],ENT_QUOTES,"UTF-8");

} else{

	$passwort = "";
}


if (isset($_POST['p'])){

	$p = $_POST['p'];

} else{

	$p = "";
}




$md5_reg = md5($userid);
$loginfo = date("j.n.Y.H:i");


$sql = "UPDATE account 

    SET  
  
	Passwort = :newpasswort 
   
    WHERE ID=:nr;";


   
try {

	$dbh = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);	
	
	$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$stmt = $dbh->prepare($sql);

	$stmt->execute(array(
		
				
		':newpasswort'=>$p,
		':nr'=>$nr
		
		));

	
	$dbh = null;
	
	echo 'Passwort:  -  update erfolgreich  - ' . $userid ; 

} catch(PDOException $e) {

	echo '{"error":{"text":'. $e->getMessage() . $sql .  $nr .	'}}'; 
} 


?>