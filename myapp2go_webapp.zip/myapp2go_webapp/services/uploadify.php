<?php
include 'config.php';

/*
Uploadify
 
*/

// Define a destination
$targetFolder = '/customerpics'; // Relative to the root

if (isset($_POST['custid'])){

	$nr = ($_POST['custid']);

} else{

	$nr = 0;
}


if (isset($_POST['append_id'])){

	$append_id = ($_POST['append_id']);

} else{

	$append_id = 0;
}


$datum = date("Y-m-d"); 
$isDeleted = 0;
$random = '';

function random_string($length) {
    $key = '';
    $keys = array_merge(range(0, 9), range('a', 'z'));

    for ($i = 0; $i < $length; $i++) {
        $key .= $keys[array_rand($keys)];
    }

    return $key;
}

$random = random_string(20);


//$verifyToken = md5('unique_salt' . $_POST['timestamp']);

if (!empty($_FILES)) {

	$tempFile = $_FILES['Filedata']['tmp_name'];
	$targetPath = $_SERVER['DOCUMENT_ROOT'] . $targetFolder;
	
	$targetFile = rtrim($targetPath,'/')       . '/'  . $nr . '_' . $random .  '_' . $_FILES['Filedata']['name'];

	if ($append_id == 0) {
	
		$copied_targetFile = rtrim($targetPath,'/') . '/' .  '_' . $nr . '_' . $random .  '_' . $_FILES['Filedata']['name'];

	}

	$targetFileOnlyName =  $nr . '_' . $random .  '_' . $_FILES['Filedata']['name'];
	
	// Validate the file type
	$fileTypes = array('jpg','jpeg','gif','png','pdf', 'doc', 'mp4'); // File extensions
	$fileParts = pathinfo($_FILES['Filedata']['name']);
	
	if (in_array($fileParts['extension'],$fileTypes)) {

		move_uploaded_file($tempFile,$targetFile);
		
		
		// nur wenn append_id = null / kein Anhang dann copy für galerie
		if ($append_id == 0) {
			
				if (!copy($targetFile, $copied_targetFile )) {
					$msg = 'copy failed';
				};
		};

		// echo 'var nr: ' . $nr;
/*
		$logfile = fopen("ma2g_logfile.log", "a"); // wird die Logdatei geöffnet
	    $logtext = $_SERVER['REMOTE_ADDR'] . " -- " . date("d.m.Y H:i:s"). " - DATEN: # " . $targetFile . " / " . $nr . " / " . $copied_targetFile . " / " . $msg . " #---ENDE \r\n\r\n"; // und die Fehlermeldung (inkl. Datum/Uhrzeit und dem Query)
	    fwrite($logfile, $logtext); // in die Logdatei geschrieben
	    fclose($logfile);          // und zum Schluss wird die Logdatei wieder geschlossen
*/

	    $sql = "INSERT INTO customerpics (
	    	custid ,
	    	picname,
	    	picinfo,
	    	date4pic,
	    	isDeleted,
	    	appendID 
	    	)

		VALUES (
			:custid,
			:picname,
			:picinfo,
			:date4pic,
			:isDeleted,
			:appendID 
			)";


try {

	$dbh = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);	
	$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$stmt = $dbh->prepare($sql);

	$stmt->execute(array(   ':custid'=>$nr,
		':picname'=>$targetFileOnlyName,
		':picinfo'=>$targetFile,
		':date4pic'=>$datum,
		':isDeleted'=>$isDeleted,
		':appendID'=>$append_id
		));


	$dbh = null;

	echo ' OK'; 

} catch(PDOException $e) {

	echo '{"error":{"text":'. $e->getMessage() . $sql . ' ---target:  ' + $targetPath .  '}}'; 
} 



} else {

	echo 'Invalid file type.';
}
}
?>