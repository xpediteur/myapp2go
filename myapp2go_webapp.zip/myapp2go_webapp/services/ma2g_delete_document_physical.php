<?php header('Access-Control-Allow-Origin: *'); ?>
<?php

include 'config.php';


// Define a destination
$targetFolder = '/customerpics'; // Relative to the root

$targetPath = $_SERVER['DOCUMENT_ROOT'] . $targetFolder;


$picname= "";
$msg = "";



if (isset($_GET['id'])){

                $id = ($_GET['id']);
                
                } else{
                
                    $id = 0;
            }

          

            $sqlpicture = "select * from customerpics where isDeleted = 1 and custid=:id;";


            try {

            	$dbh = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);	
            	$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            	$stmt = $dbh->prepare($sqlpicture);

            	$stmt->bindParam("id", $id);

            	$stmt->execute();

            	$pictures = $stmt->fetchAll(PDO::FETCH_ASSOC);

                foreach($pictures as $row) {

                   $picname = $row["picname"];


                   $targetFile = rtrim($targetPath,'/')  . '/'  . $picname ;

                   $copied_targetFile = rtrim($targetPath,'/') . '/'  .  "_" . $picname ;



                    if (file_exists($targetFile)) {

                        if (unlink($targetFile)) {

                            $msg = $msg . "delete erfolgreich :" .  $targetFile . " -- \r\n";
                        }

                    }


                    if (file_exists($copied_targetFile)) {

                       if (unlink($copied_targetFile)) {

                           $msg = $msg . "copy delete erfolgreich :" .  $copied_targetFile . " -- \r\n" ;

                       }

                    }

                    
               }


            	
            	$dbh = null;

                echo '{"items":'. json_encode($pictures) .'}'; 
                   

            	$logfile = fopen("myapp2go_logfile.log", "a"); // wird die Logdatei geöffnet
                $logtext = $_SERVER['REMOTE_ADDR'] . " -- " . date("d.m.Y H:i:s") .  " ## files : "  .  $id . " / " . $msg . " ------- \r\n\r\n"; // und die Fehlermeldung (inkl. Datum/Uhrzeit und dem Query)
                fwrite($logfile, $logtext); // in die Logdatei geschrieben
                fclose($logfile);          // und zum Schluss wird die Logdatei wieder geschlossen



            } catch(PDOException $e) {
                	
                	echo '{"error":{"text":'. $e->getMessage() .'}}'; 
                }


?>