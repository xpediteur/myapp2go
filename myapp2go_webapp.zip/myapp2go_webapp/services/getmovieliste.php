<?php header('Access-Control-Allow-Origin: *'); ?>
<?php
include 'config.php';

$clean = '';

if (isset($_GET['id'])){

                $custid = ($_GET['id']);
                
                } else{
                
                    $custid = 0;
            }


function utf8_string_array_encode(&$array){
    $func = function(&$value,&$key){
        if(is_string($value)){
            $value = utf8_encode($value);
        } 
        if(is_string($key)){
            $key = utf8_encode($key);
        }
        if(is_array($value)){
            utf8_string_array_encode($value);
        }
    };
    array_walk($array,$func);
    return $array;
}


$sqldoc = $sql = 'SELECT * FROM customerpics c, infotable i'
        . ' where custid=:id'
        . ' and   c.custid = i.UserId'
        . ' and   c.appendID = i.ItemId'
        . ' and   i.Itemtyp = "Movie"'
        . ' and   i.isDeleted = 0'
        . ' order by c.appendID DESC;';


try {

  $dbh = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);  
  $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  
  $stmt = $dbh->prepare($sqldoc);

  $stmt->bindParam("id", $custid);

    
  $stmt->execute();

  $documents = $stmt->fetchAll(PDO::FETCH_ASSOC);

 
  $dbh = null;

  $clean = utf8_string_array_encode($documents);

  echo '{"items":'. json_encode($clean) .'}'; 

  // $no=$stmt->rowCount();

  

} catch(PDOException $e) {
  
  echo '{"error":{"text":'. $e->getMessage() .'}}'; 
}

?>