<?php header('Access-Control-Allow-Origin: *'); ?>
<?php
include 'config.php';

$clean = '';

if (isset($_GET['typ'])){

				$get_typ = htmlentities($_GET['typ'],ENT_QUOTES,"UTF-8");
				
				} else{
				
					$get_typ = "";
			}

if (isset($_GET['id'])){

				$get_id = htmlentities($_GET['id'],ENT_QUOTES,"UTF-8");
				
				} else{
				
					$get_id = "0";
			}

function utf8_string_array_encode(&$array){
    $func = function(&$value,&$key){
        if(is_string($value)){
            $value = utf8_encode($value);
        } 
        if(is_string($key)){
            $key = utf8_encode($key);
        }
        if(is_array($value)){
            utf8_string_array_encode($value);
        }
    };
    array_walk($array,$func);
    return $array;
}

// $sqlnews = "select * from infotable where ItemTyp=:typ and UserId=:id and isDeleted = 0 order by Date4Item desc;";

$sqlnews = "select ItemId, ItemHeading, ItemDetails, DATE_FORMAT(Date4Item, '%d.%m.%Y') AS Date4Itemnew, UNIX_TIMESTAMP(`Date4Item` ) as u_date from infotable where ItemTyp=:typ and UserId=:id and isDeleted = 0 order by Date4Item desc, ItemId desc;";


try {
	$dbh = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);	
	$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	
	$stmt = $dbh->prepare($sqlnews);
    
	$stmt->bindParam("typ", $get_typ);
	$stmt->bindParam("id", $get_id);
	
	$stmt->execute();

	$news = $stmt->fetchAll(PDO::FETCH_OBJ);
	
	$dbh = null;

	$clean = utf8_string_array_encode($news);

	echo '{"items":'. json_encode($clean) .'}'; 

/*
	$no=$stmt->rowCount();

	$logfile = fopen("JQMBOR_logfile.log", "a"); // wird die Logdatei geöffnet
    $logtext = $_SERVER['REMOTE_ADDR'] . " -- " . date("d.m.Y H:i:s"). " - JSON Daten tourlist : " . $no . $sqlnews . " ------- \r\n\r\n"; // und die Fehlermeldung (inkl. Datum/Uhrzeit und dem Query)
    fwrite($logfile, $logtext); // in die Logdatei geschrieben
    fclose($logfile);          // und zum Schluss wird die Logdatei wieder geschlossen
*/
	

} catch(PDOException $e) {
	
	echo '{"error":{"text":'. $e->getMessage() .'}}'; 
}

?>