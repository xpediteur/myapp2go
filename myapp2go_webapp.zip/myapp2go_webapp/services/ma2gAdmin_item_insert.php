<?php
include 'config.php';



if (isset($_POST['nr'])){

	$nr = ($_POST['nr']);

} else{

	$nr = 0;
}


if (isset($_POST['userid'])){

	$userid = htmlentities($_POST['userid'],ENT_QUOTES,"UTF-8");

} else{

	$userid = "";
}

if (isset($_POST['radio-choice-b'])){

	$radio_choice_b = htmlentities($_POST['radio-choice-b'],ENT_QUOTES,"UTF-8");

} else{

	$radio_choice_b = "";
}

if (isset($_POST['heading'])){

	$heading = htmlentities($_POST['heading'],ENT_QUOTES,"UTF-8");

} else{

	$heading = "";
}



if (isset($_POST['detail'])){

	$detail = htmlentities($_POST['detail'],ENT_QUOTES,"UTF-8");

} else{

	$detail = "";
}

if (isset($_POST['date'])){

	$date = htmlentities($_POST['date'],ENT_QUOTES,"UTF-8");

} else{

	$date = "";
}


if (isset($_POST['append_id'])){

	$append_id = htmlentities($_POST['append_id'],ENT_QUOTES,"UTF-8");

} else{

	$append_id = 0;
}


//$new_detail = utf8_decode($textarea); 

// $datum = date("Y-m-d"); 

$isDeleted = 0;


$sql = "INSERT INTO infotable (
	ItemId ,
	UserId,
	ItemTyp ,
	ItemHeading ,
	ItemDetails ,
	isDeleted ,
	Date4Item,
	appendID 
	)
VALUES (
	:nr,
	:userid,
	:itemtyp,
	:itemheading,
	:itemdetail,
	:isdeleted,
	:date4item,
	:appendID 
	)";


try {

	$dbh = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);	
	$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$stmt = $dbh->prepare($sql);

	$stmt->execute(array(':nr'=>$nr,
		':userid'=>$userid,
		':itemtyp'=>$radio_choice_b,
		':itemheading'=>$heading,
		':itemdetail'=>$detail,
		':isdeleted'=>$isDeleted,
		':date4item'=>$date,
		':appendID'=>$append_id

		));


	$dbh = null;
	
	echo 'Neuer Eintrag: - ' . $heading . ' - erfolgreich'; 


 // $logfile = fopen("ma2g_logfile.log", "a"); // wird die Logdatei geöffnet
 //    $logtext = $_SERVER['REMOTE_ADDR'] . " -- " . date("d.m.Y H:i:s"). " - ". "SQL: " . $sql ." -- .\r\n\r\n"; // und die Fehlermeldung (inkl. Datum/Uhrzeit und dem Query)
 //    fwrite($logfile, $logtext); // in die Logdatei geschrieben
 //    fclose($logfile);          // und zum Schluss wird die Logdatei wieder geschlossen


} catch(PDOException $e) {

	echo '{"error":{"text":'. $e->getMessage() . $sql .  $nr .	'}}'; 
} 


?>