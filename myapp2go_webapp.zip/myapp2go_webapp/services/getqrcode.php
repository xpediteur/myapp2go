<?php header('Access-Control-Allow-Origin: *'); ?>
<?php
include('phpqrcode.php'); 

$targetFolder = '/customerpics'; // Relative to the root

if (isset($_GET['id'])){

	$id = $_GET['id'];

} else{

	$id = "";
}

if (isset($_GET['userstring'])){

	$userstring = $_GET['userstring'];

} else{

	$userstring = "QR CODE FEHLERHAFT";
}


$targetPath = $_SERVER['DOCUMENT_ROOT'] . $targetFolder;

$targetFile = rtrim($targetPath,'/')   . '/'  . $id . '_' . 'qrfile.png';

echo ( $targetFile);

QRcode::png($userstring, $targetFile, "L", 4, 4);

//echo '{"items":'. json_encode($$userstring) .'}'; 




?>


