<?php header('Access-Control-Allow-Origin: *'); ?>
<?php
include 'config.php';


if (isset($_GET['id'])){

                $custid = ($_GET['id']);
                
                } else{
                
                    $custid = 0;
            }



$sqlpicture = "select * from customerpics where custid=:id and isDeleted = 0 and appendID = 0 order by ID desc;";


try {

  $dbh = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);  
  $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  
  $stmt = $dbh->prepare($sqlpicture);

  $stmt->bindParam("id", $custid);

    
  $stmt->execute();

  $pictures = $stmt->fetchAll(PDO::FETCH_ASSOC);

 
  $dbh = null;

  echo '{"items":'. json_encode($pictures) .'}'; 

  // $no=$stmt->rowCount();

  

} catch(PDOException $e) {
  
  echo '{"error":{"text":'. $e->getMessage() .'}}'; 
}

?>