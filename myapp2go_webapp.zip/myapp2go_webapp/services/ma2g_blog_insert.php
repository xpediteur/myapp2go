<?php
include 'config.php';



if (isset($_POST['cid'])){

	$cid = ($_POST['cid']);

} else{

	$cid = 0;
}


if (isset($_POST['blog_name'])){

	$blog_name = htmlentities($_POST['blog_name'],ENT_QUOTES,"UTF-8");

} else{

	$blog_name = "";
}



if (isset($_POST['blog_heading'])){

	$blog_heading = htmlentities($_POST['blog_heading'],ENT_QUOTES,"UTF-8");

} else{

	$blog_heading = "";
}




if (isset($_POST['blog_comment'])){

	
	$blog_comment = htmlentities($_POST['blog_comment'],ENT_QUOTES,"UTF-8");

} else{

	$blog_comment = "";
}



$datum = date("Y-m-d"); 

$isDeleted = 0;
$nr = 0;


$sql = "INSERT INTO customerblog (
	ID,
	custid,
	blogername,
	blogheading,
	blogtext,
	date4blog,
	isDeleted 
	)

VALUES ( 
	:nr,
	:custid,
	:blogername,
	:blogheading,
	:blogtext,
	:date4blog,
	:isdeleted
	)";


try {

	$dbh = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);	
	$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$stmt = $dbh->prepare($sql);

	$stmt->execute(array(

		':nr'=>$nr,
		':custid'=>$cid,
		':blogername'=>$blog_name,
		':blogheading'=>$blog_heading,
		':blogtext'=>$blog_comment,
		':date4blog'=>$datum,
		':isdeleted'=>$isDeleted
	
		));


	$dbh = null;
	
	echo 'ihr Blogeintrag: - ' . $blog_heading . ' - wurde erfolgreich geposted'; 


 // $logfile = fopen("ma2g_logfile.log", "a"); // wird die Logdatei geöffnet
 //    $logtext = $_SERVER['REMOTE_ADDR'] . " -- " . date("d.m.Y H:i:s"). " - ". "SQL: " . $sql ." -- .\r\n\r\n"; // und die Fehlermeldung (inkl. Datum/Uhrzeit und dem Query)
 //    fwrite($logfile, $logtext); // in die Logdatei geschrieben
 //    fclose($logfile);          // und zum Schluss wird die Logdatei wieder geschlossen


} catch(PDOException $e) {

	echo '{"error":{"text":'. $e->getMessage() . $sql .  $nr .	'}}'; 
} 


?>