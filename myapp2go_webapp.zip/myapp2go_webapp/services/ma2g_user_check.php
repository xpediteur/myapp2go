<?php header('Access-Control-Allow-Origin: *'); ?>
<?php

include 'config.php';

$db_Id = '';
$db_UserId  = '';
$db_passwort = '';
$db_isroot = '';

$input_plain_pw = '';
$input_decrypted = '';

$db_plain_pw = '';
$db_decrypted = '';


// Benutzereingaben bereinigen und auf Injection prüfen

cleanInput();


if (isset($_POST['user'])){

	$get_user = htmlentities($_POST['user'],ENT_QUOTES,"UTF-8");

} else{

	$get_user = "";
}

if (isset($_POST['pass'])){

	$get_pass = htmlentities($_POST['pass'],ENT_QUOTES,"UTF-8");

} else{

	$get_pass = "";
}

if (isset($_POST['p'])){

	$p = $_POST['p'];

} else{

	$p = "";
}




//------------------------------------------------------------------------------------------------------   

function hextostring ($hexa){

	$string = '';
	for ($i=0; $i < strlen($hexa)-1; $i+=2) {
		$string .= chr(hexdec($hexa[$i].$hexa[$i+1]));
	}

	return $string;
}

//------------------------------------------------------------------------------------------------------      

// Benutzereingabe bereinigen (trimmen, Slashes entfernen)
function cleanInput()
{
		// checkInjection();
	if (get_magic_quotes_gpc()) $_POST = array_map( 'stripslashes', $_POST );
	$_POST = array_map( 'trim', $_POST );
}


//------------------------------------------------------------------------------------------------------       
	// Benutzereingaben auf mögliche Injection prüfen
function checkInjection()
{
	$email_injection = array( 'bcc:', 'boundary', 'cc:', 'content-transfer-encoding:', 'content-type:', 'mime-version:', 'subject:', 'javascript', 'script' );

		// Auf potentielle Email Injections prüfen
	foreach ($email_injection as $injection)
	{
		foreach ($_POST as $feld => $inhalt)
		{
			if (preg_match( "/{$injection}/i", $inhalt ))
			{
				header( 'location: http://www.google.com/search?hl=en&q=how+to+become+a+better+hacker' );
				exit;
			}
		}
	}
	return true;
}
//------------------------------------------------------------------------------------------------------       

// hex pw aus Form in normales crypiertes wandeln
$input_plain_pw = hextostring($p);

// cryptiertes pw decryptieren
$input_decrypted = str_rot13($input_plain_pw);



$sqluser = "select ID, UserId, Passwort, isroot from account where UserId=:user;";


try {
	$dbh = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);	
	$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	
	$stmt = $dbh->prepare($sqluser);

	$stmt->bindParam("user", $get_user);
	
	
	$stmt->execute();

	
	$login = $stmt->fetch();
	
	$db_UserId    = $login['UserId'];
	$db_passwort  = $login['Passwort'];
	$db_Id        = $login['ID']; 
	$db_isroot    = $login['isroot']; 

	$dbh = null;

	// hex pw aus DB in normales crypiertes wandeln
	$db_plain_pw = hextostring($db_passwort);

    // cryptiertes pw decryptieren
	$db_decrypted = str_rot13($db_plain_pw);



//	if ($db_UserId == $get_user  && $db_passwort == $pget_pass ){

	if ($db_UserId == $get_user  && $db_decrypted == $input_decrypted ){

		if ($get_user == '' || $p == '') {
			
			echo ('UserID und/oder Passwort fehlt !' ); 

		}else{

			echo ('OK' . '-' . $db_Id . '-' . $db_UserId . '-' . $db_isroot  ); 
		}

	} else {

		echo 'Kombination UserID und Passwort falsch !'; 
	}		


	/*

	$no=$stmt->rowCount();

	$logfile = fopen("myapp2go_logfile.log", "a"); // wird die Logdatei geöffnet
    $logtext = $_SERVER['REMOTE_ADDR'] . " -- " . date("d.m.Y H:i:s"). " ## Daten : "  . $db_Id  . " / " .   $get_user . ' - ' .  $p . " ------- \r\n\r\n"; // und die Fehlermeldung (inkl. Datum/Uhrzeit und dem Query)
    fwrite($logfile, $logtext); // in die Logdatei geschrieben
    fclose($logfile);          // und zum Schluss wird die Logdatei wieder geschlossen

*/

} catch(PDOException $e) {
	
	echo '{"error":{"text":'. $e->getMessage() .'}}'; 
}

?>