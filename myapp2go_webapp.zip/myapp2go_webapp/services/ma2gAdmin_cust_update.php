<?php header ('Content-type: text/html; charset=utf-8'); ?>
<?php
include 'config.php';


$md5_reg = '';
$isdeleted = 0;
$new_infotext = '';
$new_impressum = '';


if (isset($_POST['nr'])){

	$nr = ($_POST['nr']);

} else{

	$nr = 0;
}


if (isset($_POST['userid'])){

	$userid = htmlentities($_POST['userid'],ENT_QUOTES,"UTF-8");

} else{

	$userid = "";
}

if (isset($_POST['passwort'])){

	$passwort = htmlentities($_POST['passwort'],ENT_QUOTES,"UTF-8");

} else{

	$passwort = "";
}



if (isset($_POST['name1'])){

	$name1 = htmlentities($_POST['name1'],ENT_QUOTES,"UTF-8");

} else{

	$name1 = "";
}


if (isset($_POST['name2'])){

	$name2 = htmlentities($_POST['name2'],ENT_QUOTES,"UTF-8");

} else{

	$name2 = "";
}

if (isset($_POST['zusatz'])){

	$zusatz = htmlentities($_POST['zusatz'],ENT_QUOTES,"UTF-8");

} else{

	$zusatz = "";
}

if (isset($_POST['plz'])){

	$plz = htmlentities($_POST['plz'],ENT_QUOTES,"UTF-8");

} else{

	$plz = "";
}


if (isset($_POST['ort'])){

	$ort = htmlentities($_POST['ort'],ENT_QUOTES,"UTF-8");

} else{

	$ort = "";
}

if (isset($_POST['strasse'])){

	$strasse = htmlentities($_POST['strasse'],ENT_QUOTES,"UTF-8");

} else{

	$strasse = "";
}

if (isset($_POST['email'])){

	$email = htmlentities($_POST['email'],ENT_QUOTES,"UTF-8");

} else{

	$email = "";
}

if (isset($_POST['phone'])){

	$phone = htmlentities($_POST['phone'],ENT_QUOTES,"UTF-8");

} else{

	$phone = "";
}

if (isset($_POST['mobile'])){

	$mobile = htmlentities($_POST['mobile'],ENT_QUOTES,"UTF-8");

} else{

	$mobile = "";
}


// infotext
if (isset($_POST['textarea'])){

	$textarea = $_POST['textarea'];

} else{

	$textarea = "";
}

// Impressum
if (isset($_POST['textarea1'])){

	$textarea1 = $_POST['textarea1'];

} else{

	$textarea1 = "";
}


// facebookstr
if (isset($_POST['textarea2'])){

	$textarea2 = htmlentities($_POST['textarea2'],ENT_QUOTES,"UTF-8");

} else{

	$textarea2 = "";
}

// googlemapsstr
if (isset($_POST['textarea3'])){

	$textarea3 = htmlentities($_POST['textarea3'],ENT_QUOTES,"UTF-8");

} else{

	$textarea3 = "";
}

// toppic
if (isset($_POST['toppic'])){

	$toppic = htmlentities($_POST['toppic'],ENT_QUOTES,"UTF-8");

} else{

	$toppic = "";
}

// curl
if (isset($_POST['curl'])){

	$curl = htmlentities($_POST['curl'],ENT_QUOTES,"UTF-8");

} else{

	$toppic = "";
}



$md5_reg = md5($userid);
$loginfo = date("j.n.Y.H:i");
$picture = 'Bild.png';


$new_infotext = utf8_decode($textarea);

$new_impressum = utf8_decode($textarea1);

//$new_text = nl2br($textarea);


$sql = "UPDATE account 
    SET 

  
	Name1 = :name1,
	Name2 = :name2,
	NameZusatz = :zusatz,
	PLZ = :plz,
	Ort = :ort,
	Strasse = :strasse,
	Email = :email,
	Phone = :phone,
	Mobile = :mobile,
	Loginfo = :loginfo,
	Infotext = :textarea,
	Impressum = :textarea1,
	Picture = :toppic,
	URL = :curl,
	facebookstr = :textarea2,
	googlemapsstr = :textarea3
	
   
    WHERE UserId=:userid;";


   
try {

	$dbh = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);	
	
	$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$stmt = $dbh->prepare($sql);

	$stmt->execute(array(
		
		
		':name1'=>$name1,
		':name2'=>$name2,
		':zusatz'=>$zusatz,
		':plz'=>$plz,
		':ort'=>$ort,
		':strasse'=>$strasse,
		':email'=>$email,
		':phone'=>$phone,
		':mobile'=>$mobile,
		':loginfo'=>$loginfo,
		':textarea'=>$new_infotext,
		':textarea1'=>$new_impressum,
		':toppic'=>$toppic,
		':curl'=>$curl, 
		':textarea2'=>$textarea2,
		':textarea3'=>$textarea3,
		':userid'=>$userid
		
		));

	
	$dbh = null;
	
	echo 'Datensatz:  -  update erfolgreich  - ' . $userid ; 

} catch(PDOException $e) {

	echo '{"error":{"text":'. $e->getMessage() . $sql .  $nr .	'}}'; 
} 


?>