<?php header('Access-Control-Allow-Origin: *'); ?>
<?php

include 'config.php';



if (isset($_POST['nr'])){

                $custid = ($_POST['nr']);
                
                } else{
                
                    $custid = 0;
            }



            $galleryhtml = '';

            $sqlpicture = "select * from customerpics where custid=:id and isDeleted = 0 and appendID = 0 order by ID desc;";


            try {

            	$dbh = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);	
            	$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            	$stmt = $dbh->prepare($sqlpicture);

            	$stmt->bindParam("id", $custid);


            	$stmt->execute();

            	$pictures = $stmt->fetchAll(PDO::FETCH_ASSOC);

            	foreach($pictures as $row) {

            		$id = $row['custid'];
            		$p = $row['picname'];


            		$galleryhtml .= '<li><a href="customerpics/'. $p . '" rel="external" class="ui-link"><img src="customerpics/_' .  $p . '" alt="" /></a></li>';

			//echo ($id . ' #  ' . $p . "<br /> \n");

            	}


            	$dbh = null;


	// $no=$stmt->rowCount();


            	echo $galleryhtml;

/*
	$logfile = fopen("myapp2go_logfile.log", "a"); // wird die Logdatei geöffnet
    $logtext = $_SERVER['REMOTE_ADDR'] . " -- " . date("d.m.Y H:i:s"). " ## Daten : "  . $galleryhtml  . " / " .   " ------- \r\n\r\n"; // und die Fehlermeldung (inkl. Datum/Uhrzeit und dem Query)
    fwrite($logfile, $logtext); // in die Logdatei geschrieben
    fclose($logfile);          // und zum Schluss wird die Logdatei wieder geschlossen
*/


} catch(PDOException $e) {
	
	echo '{"error":{"text":'. $e->getMessage() .'}}'; 
}


?>