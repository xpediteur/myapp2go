<?php header('Access-Control-Allow-Origin: *'); ?>
<?php
include 'config.php';



// $sqlnews = "select * from infotable where ItemTyp=:typ and UserId=:id and isDeleted = 0 order by Date4Item desc;";

$sqlnews = "select * from account;";


try {
	$dbh = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);	
	$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	
	$stmt = $dbh->prepare($sqlnews);
    
	$stmt->execute();

	$news = $stmt->fetchAll(PDO::FETCH_OBJ);
	
	$dbh = null;

	echo '{"items":'. json_encode($news) .'}'; 

/*
	$no=$stmt->rowCount();

	$logfile = fopen("JQMBOR_logfile.log", "a"); // wird die Logdatei geöffnet
    $logtext = $_SERVER['REMOTE_ADDR'] . " -- " . date("d.m.Y H:i:s"). " - JSON Daten tourlist : " . $no . $sqlnews . " ------- \r\n\r\n"; // und die Fehlermeldung (inkl. Datum/Uhrzeit und dem Query)
    fwrite($logfile, $logtext); // in die Logdatei geschrieben
    fclose($logfile);          // und zum Schluss wird die Logdatei wieder geschlossen
*/
	

} catch(PDOException $e) {
	
	echo '{"error":{"text":'. $e->getMessage() .'}}'; 
}

?>