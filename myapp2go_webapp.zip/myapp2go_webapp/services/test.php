<?php

include('phpqrcode.php'); 

define('UNIQUE_SALT', '5&nL*dF4');

// test 

$crypt_pw = '';
$decrypt_pw = '';

$agent = $_SERVER['HTTP_USER_AGENT']; 

if(isset($_SERVER['HTTP_X_FORWARDED_FOR']) && $_SERVER['HTTP_X_FORWARTDED_FOR'] != '') {
	$ip_address = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
	$ip_address = $_SERVER['REMOTE_ADDR'];
}

echo $agent . "<br>";
echo $ip_address . "<br>" . "<br>";



function create_hash($string, $hash_method = 'sha1') {
	
	return hash($hash_method, UNIQUE_SALT . $string);
	
	return sha1(UNIQUE_SALT . $string);
}


function validateLogin($pass, $hashed_pass, $hash_method = 'sha1') {
	
	return ($hashed_pass === sha1($hash_method, UNIQUE_SALT . $pass));
}


$crypt_pw = create_hash("passwort");
$decrypt_pw = validateLogin("passwort", $crypt_pw);


echo $crypt_pw . "<br>";

echo $decrypt_pw . "<br>";

function random_string($length) {
	$key = '';
	$keys = array_merge(range(0, 9), range('a', 'z'));

	for ($i = 0; $i < $length; $i++) {
		$key .= $keys[array_rand($keys)];
	}

	return $key;
}


function hextostring ($hexa){

	$string = '';
	for ($i=0; $i < strlen($hexa)-1; $i+=2) {
		$string .= chr(hexdec($hexa[$i].$hexa[$i+1]));
	}

	return $string;
}

//$decrypted = str_rot13("passwort");

// echo ($decrypted);	

//echo random_string(20);



    // outputs image directly into browser, as PNG stream 
	QRcode::png("http://www.sitepoint.com", "test.png", "L", 4, 4);
/*

echo "<p>QR code</p>"; 

echo '<img src="http://system3-consulting.de/myapp2go/services/test.png" border=0>';


*/
$hexa = '';
$hexa = "67726667";

$cry = hextostring($hexa);

echo ($cry . '<br>');

$decrypted = str_rot13($cry);

echo ($decrypted);	

?>


