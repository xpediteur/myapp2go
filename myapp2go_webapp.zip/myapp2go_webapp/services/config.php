<?php

// Werte f�r connect 
// Hoster 

	//$liveserver = "system3-consulting.de";
	
	$liveserver = "www.myapp2go.de";
	
	if($liveserver == "") {
	# Werte auf Entwicklungssystem 

	$dbhost = '127.0.0.1';
	$dbuser = 'root';
	$dbpass = 'x11';
	$dbname = 'JQMPHP';
	
		} else{
        
		# Werte auf server
		$dbhost = 'db483439695.db.1and1.com';
		$dbuser = 'dbo483439695';
		$dbpass = 'strcopy1';
		$dbname = 'db483439695';


}	
?>