<?php header('Access-Control-Allow-Origin: *'); ?>
<?php
include 'config.php';


if (isset($_GET['id'])){

                $custid = ($_GET['id']);
                
                } else{
                
                    $custid = 0;  
            }



$sqlmodul = "select * from customerblog where custid=:id and isDeleted = 0 order by ID DESC ;";


try {

  $dbh = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);  
  $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  
  $stmt = $dbh->prepare($sqlmodul);

  $stmt->bindParam("id", $custid);

    
  $stmt->execute();

  $blogs = $stmt->fetchAll(PDO::FETCH_ASSOC);

 
  $dbh = null;

  echo '{"items":'. json_encode($blogs) .'}'; 

  // $no=$stmt->rowCount();

  

} catch(PDOException $e) {
  
  echo '{"error":{"text":'. $e->getMessage() .'}}'; 
}

?>