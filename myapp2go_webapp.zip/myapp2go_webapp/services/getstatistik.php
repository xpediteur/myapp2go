<?php header('Access-Control-Allow-Origin: *'); ?>
<?php
include 'config.php';


$sqlitem = "SELECT custid as ID, Name1 as Kunde, count(*) as Aufrufe from customercalls c, account a where c.custid = a.id group by c.custid, a.id ;";


try {
	$dbh = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);	
	$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	
	$stmt = $dbh->prepare($sqlitem);

	// $stmt->bindParam("typ", $get_typ);
	// $stmt->bindParam("id", $get_id);


	$stmt->execute();

	$counts = $stmt->fetchAll(PDO::FETCH_OBJ);
	
	$dbh = null;
	echo '{"items":'. json_encode($counts) .'}'; 

/*	
	$logfile = fopen("JQMBOR_logfile.log", "a"); // wird die Logdatei geöffnet
    $logtext = $_SERVER['REMOTE_ADDR'] . " -- " . date("d.m.Y H:i:s"). " - ". "JSON Daten counter: " .json_encode($counts)." -- .\r\n\r\n"; // und die Fehlermeldung (inkl. Datum/Uhrzeit und dem Query)
    fwrite($logfile, $logtext); // in die Logdatei geschrieben
    fclose($logfile);          // und zum Schluss wird die Logdatei wieder geschlossen
  */  

} catch(PDOException $e) {
	echo '{"error":{"text":'. $e->getMessage() .'}}'; 
}

?>