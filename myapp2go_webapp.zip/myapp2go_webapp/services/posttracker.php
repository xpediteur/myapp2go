<?php header('Access-Control-Allow-Origin: *'); ?>
<?php
include 'config.php';


if (isset($_POST['nr'])){

	$nr = ($_POST['nr']);

} else{

	$nr = 0;
}

$isDeleted = 0;
$datum = date('Y-m-d');

$ip_address = '';

$agent = $_SERVER['HTTP_USER_AGENT']; 

if(isset($_SERVER['HTTP_X_FORWARDED_FOR']) && $_SERVER['HTTP_X_FORWARTDED_FOR'] != '') {
    $ip_address = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip_address = $_SERVER['REMOTE_ADDR'];
}



$sql = "INSERT INTO customercalls (
	ID,
	custid,
	ip,
	info,
	date4call ,
	isDeleted 
	)
VALUES (
	:nr,
	:custid,
	:ip,
	:info,
	:date4call,
	:isdeleted
	
	)";


try {

	$dbh = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);	
	$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$stmt = $dbh->prepare($sql);

	$stmt->execute(array(':nr'=>0,
		':custid'=>$nr,
		':ip'=>$ip_address,
		':info'=>$agent,
		':date4call'=>$datum,
		':isdeleted'=>$isDeleted
		));


	$dbh = null;
	
	echo 'Neuer Eintrag: erfolgreich'; 


 // $logfile = fopen("ma2g_logfile.log", "a"); // wird die Logdatei geöffnet
 //    $logtext = $_SERVER['REMOTE_ADDR'] . " -- " . date("d.m.Y H:i:s"). " - ". "SQL: " . $sql ." -- .\r\n\r\n"; // und die Fehlermeldung (inkl. Datum/Uhrzeit und dem Query)
 //    fwrite($logfile, $logtext); // in die Logdatei geschrieben
 //    fclose($logfile);          // und zum Schluss wird die Logdatei wieder geschlossen


} catch(PDOException $e) {

	echo '{"error":{"text":'. $e->getMessage() .  $nr .	'}}'; 
} 


?>