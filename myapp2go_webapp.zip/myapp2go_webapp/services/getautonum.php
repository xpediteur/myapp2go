<?php header('Access-Control-Allow-Origin: *'); ?>
<?php
include 'config.php';



$sqlautonum = "SELECT * FROM customerautonum;";

try {

                $dbh = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);          

                $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


                $stmt = $dbh->prepare($sqlautonum);

 
		$stmt->execute();

                $num_obj = $stmt->fetchAll(PDO::FETCH_OBJ);
                

                $dbh = null;

                echo '{"items":'. json_encode($num_obj) .'}'; 
                

                // $logfile = fopen("JQMBOR_logfile.log", "a"); // wird die Logdatei geöffnet

		// $logtext = $_SERVER['REMOTE_ADDR'] . " -- " . date("d.m.Y H:i:s"). " - ". "JSON Daten counter: " .json_encode($num_obj)." -- .\r\n\r\n"; // und die Fehlermeldung (inkl. Datum/Uhrzeit und dem Query)

		// fwrite($logfile, $logtext); // in die Logdatei geschrieben

		// fclose($logfile);          // und zum Schluss wird die Logdatei wieder geschlossen

 

} catch(PDOException $e) {

                echo '{"error":{"text":'. $e->getMessage() .'}}'; 

}

?>