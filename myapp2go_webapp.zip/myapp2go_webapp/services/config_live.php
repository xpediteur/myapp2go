<?php
	
	$dbhost = 'db447450114.db.1and1.com';
	$dbuser = 'dbo447450114';
	$dbpass = 'xoraxl17	';
	$dbname = 'db447450114';

?>